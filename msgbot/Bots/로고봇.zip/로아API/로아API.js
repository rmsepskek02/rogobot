const scriptName = "로아API";
/**
 * (string) room
 * (string) sender
 * (boolean) isGroupChat
 * (void) replier.reply(message)
 * (boolean) replier.reply(room, message, hideErrorToast = false) // 전송 성공시 true, 실패시 false 반환
 * (string) imageDB.getProfileBase64()
 * (string) packageName
 */

apiKey = "bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6IktYMk40TkRDSTJ5NTA5NWpjTWk5TllqY2lyZyIsImtpZCI6IktYMk40TkRDSTJ5NTA5NWpjTWk5TllqY2lyZyJ9.eyJpc3MiOiJodHRwczovL2x1ZHkuZ2FtZS5vbnN0b3ZlLmNvbSIsImF1ZCI6Imh0dHBzOi8vbHVkeS5nYW1lLm9uc3RvdmUuY29tL3Jlc291cmNlcyIsImNsaWVudF9pZCI6IjEwMDAwMDAwMDAxMDQyNDYifQ.LbWRJAb502GgmlQfzaTtjBimxBGYmIWfE9v4zemt7AVSAbZoKTKt6FsaP2sKtO8jAbgFnyfh5RM9YmnQg2hAA0K3jXMUCOkdMKnhjuH4bnVn0LXCWfRFJUWZrEpWvgyfNyCs_ZjrdzFzPMLtptOkGWIIP_BhEcZFRXQcVvGPzvW-GI_o4AZR5BSIPUv9Yg7RgD5NrGoQlxo1B_nwty7NXZ7Lxjrt-Ck2LOLjZVu3WNDTVjaymhDBR6hZEaaQdMCrCZLdz0eO2APrTwQJOCcfDYtIGOHYwBmepRAQCiASBKq3bGt65T2J6-1pnDNa9qkpMPh-QwahSagEWtIbmp3ybw";
apiBaseURL = "https://developer-lostark.game.onstove.com";
apiURLF = ["/characters/", "/armories/characters/", "/auctions", "/guilds/rankings", "/markets", "/gamecontents"];
apiURLB = ["/siblings", "/profiles", "/equipment", "/avatars", "/combat-skills", "/engravings", "/cards", "/gems", "/colosseums", "/collectibles", "/options", "/items/", "/items","/calendar", ""];

var lostArkServerNameArr = ["루페온", "카마인", "카단", "실리안", "아만", "니나브", "아브렐슈드", "카제로스"];

var output = "";
var url = "";

function responseFix(room, msg, sender, isGroupChat, replier, imageDB, packageName) {
  
  // if(room != "한용희"){
  //   return;
  // }

  // if(msg == "123"){
  //   replier.reply("room: " + room + "\n" + 
  //   "msg: " + msg + "\n" + 
  //   "sender: " + sender + "\n" + 
  //   "isGroupChat: " + isGroupChat + "\n" + 
  //   "replier: " + replier + "\n" + 
  //   "imageDB: " + imageDB + "\n" + 
  //   "packageName: " + packageName + "\n" + 
  //   "TEST: " + getAPI("/armories/characters/"+"고로바드"+"/equipment"));
  // }
  // 출력
  try{
    if(msg == "123123무기" || msg == "123123투구" || msg == "123123상의" || msg == "123123하의" || msg == "123123장갑" || msg == "123123어깨" || msg == "123123" || msg == "123123목걸이"  || msg == "123123귀걸이"  || msg == "123123반지" || msg == "123123어빌리티 스톤" ){
      testJSON(replier,false,true,msg);
    }
    replyData(room, msg, sender, isGroupChat, replier, imageDB, packageName);
  }catch(e){
    Api.replyRoom("한용희", e + "\n" + e.lineNumber);
    replier.reply("삐빅! 에러!");
    Log.debug(e, true);
    Log.error(e, true);
  }
}

// API URL 생성 & API 결과 출력
function replyData(room, msg, sender, isGroupChat, replier, imageDB, packageName){
  // 출력 초기화
  output = "";
  var searchName = "";
  var command = "";
  var categoryCode = 0;
  var urlArr = [];
  var input;

  input = msg.split(" ");
  // 검색어
  searchName = input[1];
  // 명령어
  command = input[0];

  // 입력 값
  // 입력 값 검사
  //// TODO 입력값 검사하는 함수를 만들자 Array로 명령어 담고 for문 돌려서 검사
  if (msg.indexOf("!섬") === "-1" && msg.indexOf("!유각") === "-1") {
    if (!msg.includes("!") || msg[0] != "!" || input[1] == "" || input[1] == null){ return; }
  }
  
  output += "< "+searchName+" >"+"님의 정보"+"\n";

  // !가격 검사
  if(command.indexOf("가격") != "-1" && command.indexOf("!") == 0){
    var _searchName = "";
    for(var i=1; i<input.length; i++){
      _searchName += input[i] + " ";
    }
    output = "";
    searchName = _searchName.slice(0,_searchName.length-1);
    output += "< "+searchName+" >"+"검색 결과"+"\n";
  }
  // !섬
  if(msg.indexOf("!섬") != "-1" || msg.indexOf("!ㅅ") != "-1"){
    output = "";
    output += "< 오늘의 모험 섬 >" + "\n";
  }
  // !유각 검사
  if(msg.indexOf("!유각") != "-1" || msg.indexOf("!ㅇㄱ") != "-1"){
    output = "";
  }

  // URL 생성
  urlArr = checkInputForURL(command, searchName);

  // 데이터 가공
  output += checkInputForData(command, urlArr, searchName);

  // 결과 출력
  if (checkInputForData(command, urlArr, categoryCode) == null || checkInputForData(command, urlArr, categoryCode) == "") { 
    output = ""; 
    output += nullData(command);
    // 텍스트결과 출력
    replier.reply(output);
  }
  else{
    replier.reply(output);
  }
}

// !정보 가공
function Info(_urlArr, searchName){
  var infoAPIJSON = getAPI(_urlArr[0]);
  var infoData = "";
  var infoData2 = "";
  var infoData3 = "";
  var infoData4 = "";
  var infoData5 = "";
  var infoData6 = "";
  var infoData7 = "";
  var infoData8 = "";
  var infoProfile = "";
  var infoEngraving = "";
  var infoCard = "";
  var _infoGem = "";
  var infoGem = "";
  var infoEquipment = "";
  var infoWeaponPoint = "";
  var infoQuality = 0;
  var infoElixirNum = 0;
  var infoElixirSet = "";
  var infoSet = [];
  var infoSetEffect = "";
  var infoTranscendenceSum = 0;
  var isArkPassive = false;
  var arkEvolution = "";
  var arkEvolutionValue = "";
  var arkRealiztion = "";
  var arkRealiztionValue = "";

  // API 결과 Null 인 경우
  var infoAPIstr = JSON.stringify(infoAPIJSON);
  if (infoAPIstr == null || infoAPIJSON == null || infoAPIJSON == "") {
    return null;
  }

  infoProfile = infoAPIJSON["ArmoryProfile"];
  infoEngraving = infoAPIJSON["ArmoryEngraving"];
  infoCard = infoAPIJSON["ArmoryCard"];
  _infoGem = infoAPIJSON["ArmoryGem"];
  infoEquipment = infoAPIJSON["ArmoryEquipment"];
  isArkPassive = infoProfile["ArkPassive"]["IsArkPassive"];
  arkEvolution = infoProfile["ArkPassive"]["Points"][0]["Name"];
  arkEvolutionValue = infoProfile["ArkPassive"]["Points"][0]["Value"];
  arkRealiztion = infoProfile["ArkPassive"]["Points"][1]["Name"];
  arkRealiztionValue = infoProfile["ArkPassive"]["Points"][1]["Value"];

  // 세트효과
  if(isArkPassive == false){
    var weaponSet = tooltipJSON(infoEquipment,"무기",false,true,isArkPassive)[3];
    var gloveSet = tooltipJSON(infoEquipment,"장갑",false,true,isArkPassive)[3];
    infoSet.push((weaponSet == "장착") ? gloveSet : weaponSet);
    infoSet.push(gloveSet);
    infoSet.push(tooltipJSON(infoEquipment,"투구",false,true,isArkPassive)[3]);
    infoSet.push(tooltipJSON(infoEquipment,"상의",false,true,isArkPassive)[3]);
    infoSet.push(tooltipJSON(infoEquipment,"하의",false,true,isArkPassive)[3]);
    infoSet.push(tooltipJSON(infoEquipment,"어깨",false,true,isArkPassive)[3]);
    var result = {};
    infoSet.forEach((x) => {
      result[x] = (result[x] || 0)+1;
    });
    var keys = Object.keys(result); 
    for (var i=0; i<keys.length; i++) {
      var key = keys[i];
      infoSetEffect += result[key] + key;
    }
  }

  // 품질
  infoQuality += + Math.round(((
    tooltipJSON(infoEquipment,"무기",false,true,isArkPassive)[2] 
  + tooltipJSON(infoEquipment,"투구",false,true,isArkPassive)[2] 
  + tooltipJSON(infoEquipment,"상의",false,true,isArkPassive)[2]
  + tooltipJSON(infoEquipment,"하의",false,true,isArkPassive)[2]
  + tooltipJSON(infoEquipment,"장갑",false,true,isArkPassive)[2]
  + tooltipJSON(infoEquipment,"어깨",false,true,isArkPassive)[2]
  + tooltipJSON(infoEquipment,"목걸이",false,false,isArkPassive)[2]
  + tooltipJSON(infoEquipment,"귀걸이",false,false,isArkPassive)[2]
  + tooltipJSON(infoEquipment,"반지",false,false,isArkPassive)[2])/11)*10)/10;

  // 엘릭서 세트
  var infoElixirSet01 = tooltipJSON(infoEquipment,"투구",true,true)[4].replace("연성 추가 효과 ", "");
  var infoElixirSet02 = infoElixirSet01.replace(" (", " Lv.");
  var infoElixirSet03 = infoElixirSet02.replace("단계)", "");
  infoElixirSet += infoElixirSet03;

  // 엘릭서 합
  infoElixirNum +=
  + (tooltipJSON(infoEquipment,"투구",true,true,isArkPassive)[1] 
  + tooltipJSON(infoEquipment,"상의",true,true,isArkPassive)[1]
  + tooltipJSON(infoEquipment,"하의",true,true,isArkPassive)[1]
  + tooltipJSON(infoEquipment,"장갑",true,true,isArkPassive)[1]
  + tooltipJSON(infoEquipment,"어깨",true,true,isArkPassive)[1]);

  // 초월 합
  infoTranscendenceSum +=
   (tooltipJSON(infoEquipment,"무기",false,true,isArkPassive)[5] 
  + tooltipJSON(infoEquipment,"투구",false,true,isArkPassive)[5] 
  + tooltipJSON(infoEquipment,"상의",false,true,isArkPassive)[5]
  + tooltipJSON(infoEquipment,"하의",false,true,isArkPassive)[5]
  + tooltipJSON(infoEquipment,"장갑",false,true,isArkPassive)[5]
  + tooltipJSON(infoEquipment,"어깨",false,true,isArkPassive)[5]);

  // 서버/클래스/세트효과/길드
  if(isArkPassive == false)
    infoData2 += infoProfile["ServerName"] + "/" + infoProfile["CharacterClassName"] + "/" + infoSetEffect + "/" + infoProfile["GuildName"] + "\n Ark OFF " + "[" + arkEvolution + " : " + arkEvolutionValue + "]" + "[" + arkRealiztion + " : " + arkRealiztionValue + "]" + "\n\n템렙/전/원/무강/품\n";
  else
    infoData2 += infoProfile["ServerName"] + "/" + infoProfile["CharacterClassName"] + "/" + infoProfile["GuildName"] + "\n Ark ON " + "[" + arkEvolution + " : " + arkEvolutionValue + "]" + "[" + arkRealiztion + " : " + arkRealiztionValue + "]" + "\n\n템렙/전/원/무강/품\n";

  // 무강
  for(var i=0; i<infoEquipment.length; i++){
    if(infoEquipment[i]["Type"] == "무기"){
      var infoWeapon = infoEquipment[i]["Name"].split(" ");
      infoWeaponPoint = infoWeapon[0].slice(1,infoWeapon.length);
    }
  }
  // 템렙/전/원/무강/품질
  infoData2 += infoProfile["ItemAvgLevel"].slice(0,infoProfile["ItemAvgLevel"].length-3) + "/" + infoProfile["CharacterLevel"] + "/" + infoProfile["ExpeditionLevel"] + "/" + infoWeaponPoint + "/" + infoQuality +"\n\n각인 ";

  // 각인
  if(isArkPassive == false){
    for(var i=0; i<infoEngraving["Effects"].length; i++){
      var engName = infoEngraving["Effects"][i]["Name"];
      infoData2 += engName.slice(0,1) + engName.slice(engName.length-1,engName.length) + " ";
    }
  }
  else{
    for(var i=0; i<infoEngraving["ArkPassiveEffects"].length; i++){
      var arkEngName = infoEngraving["ArkPassiveEffects"][i]["Name"];
      var arkEngGrade = infoEngraving["ArkPassiveEffects"][i]["Grade"];
      var arkEngGradeLv = infoEngraving["ArkPassiveEffects"][i]["Level"];
      
      if(arkEngGrade == "유물")
        arkEngGrade = "";

      infoData2 += arkEngName.slice(0,1) + arkEngGrade.slice(0,1) + arkEngGradeLv + " ";
    }
    infoData2 += "\n스톤 ";
    for(var j=0; j<infoEngraving["ArkPassiveEffects"].length; j++){
      var _arkEngName = infoEngraving["ArkPassiveEffects"][j]["Name"];
      var arkEngStoneLv = infoEngraving["ArkPassiveEffects"][j]["AbilityStoneLevel"];
      if(arkEngStoneLv != null){
        infoData2 += _arkEngName.slice(0,1) + arkEngStoneLv + " ";
      }
    }
  }

  // 체공
  infoData2 += "\n체공 ";
  for(var i=0; i< infoProfile["Stats"].length; i++){
    var statPoint = infoProfile["Stats"][i]["Value"];
    var statType = infoProfile["Stats"][i]["Type"];
    if(parseInt(statPoint) > 99 ){
    }
    if(statType == "최대 생명력"){
      infoData2 += statPoint + " / " ;
    }
    if(statType == "공격력"){
      infoData2 += statPoint ;
    }
  }

  // 특성
  infoData2 += "\n특성 ";
  for(var i=0; i< infoProfile["Stats"].length; i++){
    var statPoint = infoProfile["Stats"][i]["Value"];
    var statType = infoProfile["Stats"][i]["Type"];
    if(parseInt(statPoint) > 99 && statType != "공격력" && statType != "최대 생명력"){
      infoData2 += statType + statPoint + "/";
    }
  }
  infoData3 = infoData2.slice(0, infoData2.length-1);

  // 보석
  infoData3 += "\n멸홍  " ;
  if(_infoGem["Gems"] != null){
    infoGem = _infoGem["Gems"].sort((a,b) => {return b.Level - a.Level})
    for(var i=0; i< infoGem.length; i++){
      var gemsName = infoGem[i]["Name"]
      var gemsLevel = infoGem[i]["Level"]
      if(gemsName.indexOf("멸화") != "-1"){
        infoData3 += gemsLevel + ",";
      }
    }
    infoData4 = infoData3.slice(0, infoData3.length-1) + "/ ";
    for(var i=0; i< infoGem.length; i++){
      var gemsName = infoGem[i]["Name"]
      var gemsLevel = infoGem[i]["Level"]
      if(gemsName.indexOf("홍염") != "-1"){
        infoData4 += gemsLevel + ",";
      }
    }
    infoData5 = infoData4.slice(0, infoData4.length-1) + "\n겁작  ";
    for(var i=0; i< infoGem.length; i++){
      var gemsName = infoGem[i]["Name"]
      var gemsLevel = infoGem[i]["Level"]
      if(gemsName.indexOf("겁화") != "-1"){
        infoData5 += gemsLevel + ",";
      }
    }
    infoData6 = infoData5.slice(0, infoData5.length-1) + "/";
    for(var i=0; i< infoGem.length; i++){
      var gemsName = infoGem[i]["Name"]
      var gemsLevel = infoGem[i]["Level"]
      if(gemsName.indexOf("작열") != "-1"){
        infoData6 += gemsLevel + ",";
      }
    }
    infoData7 = infoData6.slice(0, infoData6.length-1);
    var gemDes = _infoGem["Effects"]["Description"] == "" ? "0%" :_infoGem["Effects"]["Description"].split(':')[1].trim();
    infoData7 += "\n보공 " + gemDes;
  }
  else{
    infoData7 += infoData3.slice(0, infoData5.length-3) + "보석 " + "쌀";
  }

  // 엘릭
  infoData7 += "\n엘릭 " + infoElixirSet + " (" + infoElixirNum +")";

  // 초월
  infoData7 += "\n초월 " + infoTranscendenceSum + "\n";

  // 카드
  infoData7 += infoCard["Effects"][0]["Items"][infoCard["Effects"][0]["Items"].length-1]["Name"] + "\n";
  infoData += infoData7;
  infoData8 += "https://iloa.gg/character/" + searchName;
  infoData += infoData8;
  return infoData;
}

// !스킬 가공
function Skills(_urlArr){
  var skillsAPIJSON = getAPI(_urlArr[0]);
  var _skillsData = "";
  var skillFilterRune = [];

  // API 결과 Null 인 경우
  var skillsAPIstr = JSON.stringify(skillsAPIJSON);
  if (skillsAPIstr == null || skillsAPIJSON == null || skillsAPIJSON == "") {
    return null;
  }
  
  // 룬 장착 여부 == 사용 여부
  for (var i = 0; i < skillsAPIJSON.length; i++){
    if(skillsAPIJSON[i]["Rune"] != null){
      skillFilterRune.push(skillsAPIJSON[i]);
    }
  }

  // 레벨 순 정렬
  var levelResult = skillFilterRune.sort((a,b) => {
    let x = parseInt(a.Level);
    let y = parseInt(b.Level);
    if (x < y) { return 1; }
    if (x > y) { return -1; }
    return 0;
  });

  for (var i = 0; i < levelResult.length; i++){
    _skillsData += "Lv"+levelResult[i]["Level"]
                 +" ["+levelResult[i]["Rune"]["Grade"]
                 +levelResult[i]["Rune"]["Name"]+"]"
                 +" ["+levelResult[i]["Name"]+"]"+"\n"+"   ";
    for (var j = 0; j < levelResult[i]["Tripods"].length; j++){
      if( levelResult[i]["Tripods"][j]["IsSelected"] == true ){
        var tripodsName = levelResult[i]["Tripods"][j]["Name"].split(" ")
        for(var k = 0; k < tripodsName.length; k++){
          if ( tripodsName.length < 2){ _skillsData += tripodsName[k].slice(0,2); }
          else{ _skillsData += tripodsName[k].slice(0,1); }
        }
        _skillsData += levelResult[i]["Tripods"][j]["Level"]+ " ";
      }
    }
    _skillsData += "\n"
  }
  var _skillsData2 = _skillsData.slice(0, _skillsData.length - 2);
  return _skillsData2;
}

// !배럭 가공
function Characters(_urlArr){
  var charactersAPIJSON = getAPI(_urlArr[0]);
  var _charactersData = "";

  // API 결과 Null 인 경우
  var charactersAPIstr = JSON.stringify(charactersAPIJSON);
  if (charactersAPIstr == null || charactersAPIJSON == null || charactersAPIJSON == "") {
    return null;
  }

  // 레벨 순 정렬
  var levelResult = charactersAPIJSON.sort((a,b) => {
    let x = parseFloat(a.ItemMaxLevel.replace(/,/gi, "").toLowerCase());
    let y = parseFloat(b.ItemMaxLevel.replace(/,/gi, "").toLowerCase());
    if (x < y) { return 1; }
    if (x > y) { return -1; }
    return 0;
  });
  var maxLevelSerever = levelResult[0]["ServerName"];

  // 계정 서버 리스트 
  var serverNameArrTemp = [];
  var serverNameArr = [];
  for(var i = 0; i < charactersAPIJSON.length; i++){
    var charactersServerName = charactersAPIJSON[i]["ServerName"];
    serverNameArrTemp.push(charactersServerName);
  }
  for(var i = 0; i < serverNameArrTemp.length; i++){
    if(!serverNameArr.includes(serverNameArrTemp[i])){
      serverNameArr.push(serverNameArrTemp[i]);
    }
  }

  // 가장 렙이 높은 캐릭터의 서버 원정대
  var gold1 = 0;
  var gold2 = 0;
  var _charactersDataTemp = ""
  _charactersDataTemp += "["+maxLevelSerever+"]"+"\n";
  for(var i = 0; i < levelResult.length; i++){
    if (maxLevelSerever == levelResult[i]["ServerName"]){
      var charLv = parseInt(levelResult[i]["ItemMaxLevel"].replace(/,/gi, ""), 10);
      if(1640 <= charLv){ gold1 += 81000; gold2 += 60000;}
      else if(1640 > charLv && 1630 <= charLv){ gold1 += 72000; gold2 += 51500; }
      else if(1630 > charLv && 1620 <= charLv){ gold1 += 40500; gold2 += 40500; }
      else if(1620 > charLv && 1610 <= charLv){ gold1 += 27000; gold2 += 27000; }
      else if(1610 > charLv && 1600 <= charLv){ gold1 += 19600; gold2 += 18800; }
      else if(1600 > charLv && 1580 <= charLv){ gold1 += 15800; gold2 += 13800; }
      else if(1580 > charLv){ gold1 += 0; gold2 += 0; }

      _charactersDataTemp += "Lv"+levelResult[i]["ItemMaxLevel"].replace(/,/gi, "")
                            +" ["+levelResult[i]["CharacterClassName"].substring(0,2)+"]"
                            +" "+levelResult[i]["CharacterName"]+"\n";
      if (i == 5){
        _charactersDataTemp += "●주급 ["+ gold1 + "G] [" + gold2 + "G]\n\n";
      }
    }
  }

  // 다른 서버 원정대
  for(var i = 0; i < serverNameArr.length; i++){
    if (serverNameArr[i] != maxLevelSerever) {
      _charactersDataTemp += "["+serverNameArr[i]+"]"+"\n";
      for(var j = 0; j < levelResult.length; j++){
        if (serverNameArr[i] == levelResult[j]["ServerName"]){
          _charactersDataTemp += "Lv"+levelResult[j]["ItemMaxLevel"].replace(/,/gi, "")
                                +" ["+levelResult[j]["CharacterClassName"].substring(0,2)+"]"
                                +" "+levelResult[j]["CharacterName"]+"\n";
        }
      }
    }
  }

  var _charactersDataTemp2 = _charactersDataTemp.slice(0, _charactersDataTemp.length - 1);
  _charactersData = _charactersDataTemp2;
  return _charactersData;
}

// !보석 가공
function Gems(_urlArr){
  var gemsAPIJSON = getAPI(_urlArr[0]);
  var gemsData = '{"GemsData" : [';

  // API 결과 Null 인 경우
  var gemAPIstr = JSON.stringify(gemsAPIJSON);
  if (gemAPIstr == null || gemsAPIJSON == null) {
    return null;
  }
  if (gemsAPIJSON["Gems"] == null || gemsAPIJSON["Gems"] == "") {
    return null;
  }

  for (var i = 0; i < gemsAPIJSON["Gems"].length;  i++) {
    var slot = JSON.stringify(gemsAPIJSON["Gems"][i]["Slot"]);
      for(var j = 0; j < gemsAPIJSON["Effects"]["Skills"].length; j ++){
        var gemSlot = JSON.stringify(gemsAPIJSON["Effects"]["Skills"][j]["GemSlot"]);
        if (slot == gemSlot){
          // 멸화 홍염
          var slotName =  JSON.stringify(gemsAPIJSON["Gems"][i]["Name"]);
          var _slotName1 = slotName.replace(/의 보석/gi, "");
          var _slotName2 = _slotName1.replace(/레벨/gi, "");
          var _slotName3 = _slotName2.replace(/10 /gi, "10");
          // 렙
          var gemsLevel = JSON.stringify(gemsAPIJSON["Gems"][i]["Level"]);
          // 스킬 이름
          var gemSlotName = JSON.stringify(gemsAPIJSON["Effects"]["Skills"][j]["Name"]);
          // 이미지
          var gemImage = JSON.stringify(gemsAPIJSON["Gems"][i]["Icon"]);
          gemsData += '{"GemsName" : ' + _slotName3 + ',';
          gemsData += '"GemsLevel" : ' + "\"" + gemsLevel + "\"" + ',';
          gemsData += '"GemsImage" : ' + gemImage + ',';
          gemsData += '"GemsEffect" : ' + gemSlotName + '},';
        }
      }
  }
  var gemsTemp = gemsData.slice(0, gemsData.length - 1);
  gemsTemp += ']}';
  // API 결과 JSON 반환
  var gemsJson = JSON.parse(gemsTemp);
  // JSON 객체 정렬
  var levelResult = gemsJson["GemsData"].sort((a,b) => {return b.GemsLevel - a.GemsLevel})

  // JSON to String
  var gemsName = "";
  var gemsEffect = "";
  gemsData = "";
  for (i = 0; i < gemsJson["GemsData"].length; i++){
    gemsName = levelResult[i]["GemsName"];
    gemsEffect = levelResult[i]["GemsEffect"];
    gemsData += gemsName + gemsEffect + "\n";
  }
  var _gemsData = gemsData.slice(0, gemsData.length - 1);
  var _gemsData2 = _gemsData.replace(/\n /gi, "\n");
  var _gemsData3 = _gemsData2.slice(1);
  return _gemsData3;
}

// !장비 & 악세 함수
function tooltipJSON (_equipmentAPIJSON, type, isElixir, isEquip, isArk) {
  var data = "";
  var elixirSum = 0;
  var qualityValue = 0;
  var transcendenceSum = 0;
  var setEffect = "";
  var elixirEffect = "";
  for (var i = 0; i < _equipmentAPIJSON.length;  i++) {
    if(_equipmentAPIJSON[i]["Type"] == type){
      var test = JSON.stringify(_equipmentAPIJSON[i]["Tooltip"]);
      var test1 = test.replace(/\\/gi, "");
      var test2 = test1.replace(/rn/gi, "");
      var test3 = test2.replace(/"Element_000": { "type":/gi, "},{ \"type\":");
      var test4 = test3.replace(/"Element_001": { "type":/gi, "{ \"type\":");
      var test5 = test4.replace(/"Element_002": { "type":/gi, "{ \"type\":");
      var test6 = test5.replace(/"Element_003": { "type":/gi, "{ \"type\":");
      var test7 = test6.replace(/"Element_004": { "type":/gi, "{ \"type\":");
      var test8 = test7.replace(/"Element_005": { "type":/gi, "{ \"type\":");
      var test9 = test8.replace(/"Element_006": { "type":/gi, "{ \"type\":");
      var test10 = test9.replace(/"Element_007": { "type":/gi, "{ \"type\":");
      var test11 = test10.replace(/"Element_008": { "type":/gi, "{ \"type\":");
      var test12 = test11.replace(/"Element_009": { "type":/gi, "{ \"type\":");
      var test13 = test12.replace(/"Element_010": { "type":/gi, "{ \"type\":");
      var test14 = test13.replace(/"Element_011": { "type":/gi, "{ \"type\":");
      var test15 = test14.replace(/"Element_012": { "type":/gi, "{ \"type\":");
      var test16 = test15.replace(/"Element_013": { "type":/gi, "{ \"type\":");
      var test17 = test16.replace(/"Element_014": { "type":/gi, "{ \"type\":");
      var test18 = test17.replace(/"Element_015": { "type":/gi, "{ \"type\":");
      var test19 = test18.replace(/"Element_016": { "type":/gi, "{ \"type\":");
      var test20 = test19.replace(/"Element_017": { "type":/gi, "{ \"type\":");
      var test21 = test20.replace(/"Element_018": { "type":/gi, "{ \"type\":");
      var test22 = test21.replace(/"{ },/gi, "[");
      var test23 = test22.replace(/}"/gi, "]");
      var _equipTooltipJSON = JSON.parse(test23);
      //장비
      if(isEquip == true){
        if(isElixir == false){
          for(var j = 0; j < _equipTooltipJSON.length; j++){
            // 재련수치
            if(_equipTooltipJSON[j]["type"] == "NameTagBox"){
              var equipment = _equipTooltipJSON[j]["value"];
              data += type + ": " + equipment.slice(2, 4) + "[00";
            }
            // 상급 재련
            if(_equipTooltipJSON[j]["type"] == "SingleTextBox"){
              if(_equipTooltipJSON[j]["value"].indexOf("상급 재련") != "-1")
              {
                var modifiedString = data.slice(0, -2);
                data = modifiedString;
                var startIndex = _equipTooltipJSON[j]["value"].indexOf("[상급 재련]");
                var endIndex = _equipTooltipJSON[j]["value"].indexOf("단계") + 2; 
                var extractedString = _equipTooltipJSON[j]["value"].slice(startIndex + "[상급 재련] ".length, endIndex - 2);
                if (extractedString.length === 1) {
                  data += "0" + extractedString;
                }
                else if (extractedString.length === 2){
                  data += "" + extractedString + "] ";
                }
              }
            }
            // 세트효과
            if(isArk == false){
              if(_equipTooltipJSON[j]["type"] == "ItemPartBox"){
                if(_equipTooltipJSON[j]["value"]["Element_000"].indexOf("세트") != "-1"){
                  var set0 = _equipTooltipJSON[j]["value"]["Element_001"].substring(0,2);
                  if(set0 == "장착"){
                    data += "짱쎔";
                  }else{
                    data += set0 + " ";
                  }
                  setEffect = set0;
                }
              }
            }
          }
          // 품질
          for(var j = 0; j < _equipTooltipJSON.length; j++){
            if(_equipTooltipJSON[j]["type"] == "ItemTitle"){
              data += "(" + _equipTooltipJSON[j]["value"]["qualityValue"] + ")" + " ";
              // if(type == "무기"){
              //   data += "\n";
              // }
              qualityValue += parseInt(_equipTooltipJSON[j]["value"]["qualityValue"]);
            }
          }
          // 초월
          for(var m = 0; m < _equipTooltipJSON.length; m++){
            if(_equipTooltipJSON[m]["type"] == "IndentStringGroup"){
              if(_equipTooltipJSON[m]["value"] == null){
                continue;
              }
              if(_equipTooltipJSON[m]["value"]["Element_000"]["topStr"].indexOf("초월") != "-1"){
                var transcendence = _equipTooltipJSON[m]["value"]["Element_000"]["topStr"];
                var startIndex = _equipTooltipJSON[m]["value"]["Element_000"]["topStr"].indexOf("[초월]");
                var extractedString = _equipTooltipJSON[m]["value"]["Element_000"]["topStr"].slice(startIndex + "[초월]".length).trim();
                data += extractedString;
                transcendenceSum += parseInt(transcendence.slice(transcendence.length-2,transcendence.length));
              }
            }
          }
        }
        // 엘릭서
        else{
          for(var k = 0; k < _equipTooltipJSON.length; k++){
            if(_equipTooltipJSON[k]["type"] == "IndentStringGroup"){
              if(_equipTooltipJSON[k]["value"] == null){
                continue;
              }
              if(_equipTooltipJSON[k]["value"]["Element_000"]["contentStr"]["Element_000"]["bPoint"] == true){
                if(_equipTooltipJSON[k]["value"]["Element_000"]["contentStr"]["Element_000"]["contentStr"].indexOf("[") != "-1"){
                  var contentStr1 = _equipTooltipJSON[k]["value"]["Element_000"]["contentStr"]["Element_000"]["contentStr"];
                  var contentStr2 = contentStr1.slice(contentStr1.search("]")+2,contentStr1.search("Lv")+4);
                  var elixirNum = contentStr1.slice(contentStr1.search("Lv")+3,contentStr1.search("Lv")+4);
                  elixirSum += parseInt(elixirNum);
                  data += type + ": " + contentStr2;
                  if(Object.keys(_equipTooltipJSON[k]["value"]["Element_000"]["contentStr"]).length == 1){
                    data += "\n";
                  }
                }
                if(Object.keys(_equipTooltipJSON[k]["value"]["Element_000"]["contentStr"]).length > 1){
                  if(_equipTooltipJSON[k]["value"]["Element_000"]["contentStr"]["Element_001"]["contentStr"].indexOf("[") != "-1"){
                    var contentStr3 = _equipTooltipJSON[k]["value"]["Element_000"]["contentStr"]["Element_001"]["contentStr"];
                    var contentStr4 = contentStr3.slice(contentStr3.search("]")+1,contentStr3.search("Lv")+4);
                    var elixirNum = contentStr3.slice(contentStr3.search("Lv")+3,contentStr3.search("Lv")+4);
                    elixirSum += parseInt(elixirNum);
                    data += contentStr4 + "\n";
                  }
                }
              }
            }
          }
          for(var k = 0; k < _equipTooltipJSON.length; k++){
            if(_equipTooltipJSON[k]["type"] == "IndentStringGroup"){
              if(_equipTooltipJSON[k]["value"] == null){
                continue;
              }
              if(_equipTooltipJSON[k]["value"]["Element_000"]["contentStr"]["Element_000"]["bPoint"] == true){
                if(_equipTooltipJSON[k]["value"]["Element_000"]["contentStr"]["Element_000"]["contentStr"].indexOf("단계 :") != "-1"){
                  elixirEffect = _equipTooltipJSON[k]["value"]["Element_000"]["topStr"];
                }
              }
            }
          }
        }

      }
      //악세
      else{
        for(var j = 0; j < _equipTooltipJSON.length; j++){
          // 등급 이름
          if(_equipTooltipJSON[j]["type"] == "ItemTitle"){
            if(_equipTooltipJSON[j]["value"] == null){
              continue;
            }
            var accessory = _equipTooltipJSON[j]["value"];
            if(accessory["leftStr0"].indexOf("이") != "-1"){
              if(isArk == true)
                data += accessory["leftStr0"].slice(0, accessory["leftStr0"].length - 1);
              else
                data += accessory["leftStr0"].slice(0, accessory["leftStr0"].length - 2);
            }
            else if(type == "팔찌"){
              data += "\n\n" + accessory["leftStr0"] + "\n";
            }
            else if(type == "반지"){
              if(isArk == true)
                data += accessory["leftStr0"];
              else
                data += accessory["leftStr0"].slice(0, accessory["leftStr0"].length - 1);
            }
            else{
              data += accessory["leftStr0"];
            }
          }
          // 각인효과
          if(_equipTooltipJSON[j]["type"] == "IndentStringGroup"){
            if(_equipTooltipJSON[j]["value"] == null){
              continue;
            }
            var engrave00 = _equipTooltipJSON[j]["value"]["Element_000"]["contentStr"]["Element_000"]["contentStr"]
            var engrave01 = _equipTooltipJSON[j]["value"]["Element_000"]["contentStr"]["Element_001"]["contentStr"]
            var engrave1 = engrave00.slice(1,2);
            var engrave2 = engrave00.slice(engrave00.length-2,engrave00.length-1);
            var engrave3 = engrave01.slice(1,2);
            var engrave4 = engrave01.slice(engrave01.length-2,engrave01.length-1);
            var engrave5 = " " + engrave1 + engrave2 + " " + engrave3 + engrave4 + " ";
            data += engrave5;
          }
        }
        if(isArk == false){
          // 특성
          for(var j = 0; j < _equipTooltipJSON.length; j++){
            if(_equipTooltipJSON[j]["type"] == "ItemPartBox"){
              if(_equipTooltipJSON[j]["value"]["Element_000"] == "추가 효과"){
                var cha0 = _equipTooltipJSON[j]["value"]["Element_001"];
                var cha1 = cha0.replace(/치명 /gi,"치");
                var cha2 = cha1.replace(/특화 /gi,"특");
                var cha3 = cha2.replace(/신속 /gi,"신");
                var cha4 = cha3.replace(/제압 /gi,"제");
                var cha5 = cha4.replace(/인내 /gi,"인");
                var cha6 = cha5.replace(/숙련 /gi,"숙");
                data += cha6;
              }
            }
          }
        }
        // 품질
        for(var j = 0; j < _equipTooltipJSON.length; j++){
          if(_equipTooltipJSON[j]["type"] == "ItemTitle"){
            if(type == "어빌리티 스톤" || type == "팔찌"){}
            else{
              if(isArk == true)
                data += "(" + _equipTooltipJSON[j]["value"]["qualityValue"] + ") [";
              else
                data += "(" + _equipTooltipJSON[j]["value"]["qualityValue"] + ")" + "\n";
              qualityValue += parseInt(_equipTooltipJSON[j]["value"]["qualityValue"]);
            }
          }
          if(_equipTooltipJSON[j]["type"] == "ItemPartBox"){
            if(_equipTooltipJSON[j]["value"]["Element_000"].indexOf("포인트") != "-1"){
              var realization = _equipTooltipJSON[j]["value"]["Element_001"];
              data += realization.replace(/깨달음 +\+/gi,"") + "]\n-";
            }
          }
        }
        for(var k = 0; k < _equipTooltipJSON.length; k++){
          if(_equipTooltipJSON[k]["type"] == "ItemPartBox"){
            if(_equipTooltipJSON[k]["value"]["Element_000"].indexOf("연마") != "-1"){
              var accessory = _equipTooltipJSON[k]["value"]["Element_001"]
              var accessory1 = accessory.replace(/추가 피해 \+/gi," 추피 ");
              var accessory2 = accessory1.replace(/적에게 주는 피해 \+/gi," 적주피 ");
              var accessory3 = accessory2.replace(/무기 공격력 \+/gi," 무공 ");
              var accessory4 = accessory3.replace(/세레나데, 신앙, 조화 게이지 획득량 \+/gi," 아획량 ");
              var accessory5 = accessory4.replace(/최대 생명력 \+/gi," 최생 ");
              var accessory6 = accessory5.replace(/최대 마나 \+/gi," 최마 ");
              var accessory7 = accessory6.replace(/상태이상 공격 지속시간 \+/gi," 상공지 ");
              var accessory8 = accessory7.replace(/전투 중 생명력 회복량 \+/gi," 생회 ");
              var accessory9 = accessory8.replace(/파티원 회복 효과 \+/gi," 파회 ");
              var accessory10 = accessory9.replace(/파티원 보호막 효과 \+/gi," 파보 ");
              var accessory11 = accessory10.replace(/치명타 적중률 \+/gi," 치적 ");
              var accessory12 = accessory11.replace(/치명타 피해 \+/gi," 치피 ");
              var accessory13 = accessory12.replace(/아군 공격력 강화 효과 \+/gi," 아공 ");
              var accessory14 = accessory13.replace(/아군 피해량 강화 효과 \+/gi," 아피 ");
              var accessory14 = accessory13.replace(/공격력 \+/gi," 공격력 ");

              data += accessory14 + "\n"
            }
          }
        }
        // 팔찌효과
        if(type == "팔찌"){
          for(var j = 0; j < _equipTooltipJSON.length; j++){
            if(_equipTooltipJSON[j]["type"] == "ItemPartBox"){
              if(_equipTooltipJSON[j]["value"]["Element_000"] == "팔찌 효과"){
                var bracelet = _equipTooltipJSON[j]["value"]["Element_001"].replace(/\[/gi,"\n\[")
                var bracelet1 = bracelet.replace(/치명 \+/gi,"\n 치명 ");
                var bracelet2 = bracelet1.replace(/특화 \+/gi,"\n 특화 ");
                var bracelet3 = bracelet2.replace(/신속 \+/gi,"\n 신속 ");
                var bracelet4 = bracelet3.replace(/제압 \+/gi,"\n 제압 ");
                var bracelet5 = bracelet4.replace(/인내 \+/gi,"\n 인내 ");
                var bracelet6 = bracelet5.replace(/숙련 \+/gi,"\n 숙련 ");
                var bracelet7 = bracelet6.replace(/최대 생명력 \+/gi,"\n 최대 생명력 ");
                var bracelet8 = bracelet7.replace(/최대 마나 \+/gi,"\n 최대 마나 ");
                var bracelet9 = bracelet8.replace(/물리 방어력 \+/gi,"\n 물리 방어력 ");
                var bracelet10 = bracelet9.replace(/마법 방어력 \+/gi,"\n 마법 방어력 ");
                var bracelet11 = bracelet10.replace(/전투 중 생명력 회복량 \+/gi,"\n 전투 중 생명력 회복량 ");
                var bracelet12 = bracelet11.replace(/무기 공격력 \+/gi,"\n 무기 공격력 ");
                var bracelet13 = bracelet12.replace(/체력 \+/gi,"\n 체력 ");
                var bracelet14 = bracelet13.replace(/힘 \+/gi,"\n 힘 ");
                var bracelet15 = bracelet14.replace(/민첩 \+/gi,"\n 민첩 ");
                var bracelet16 = bracelet15.replace(/지능 \+/gi,"\n 지능 ");
                data += bracelet16
              }
            }
          }
        }
      }
    }
  }
  return [data, elixirSum, qualityValue, setEffect, elixirEffect, transcendenceSum]
}
// !장비 가공
function Equipemnt(_urlArr, _searchName){
  var infoProfile = "";
  var infoEquipment = "";
  var equipmentData = "";
  var equipmentData2 = "";
  var isArkPassive = false;
  
  // API 결과 Null 인 경우
  var equipmentAPIJSON = getAPI(_urlArr[0]);
  var equipmentAPIstr = JSON.stringify(equipmentAPIJSON);
  if (equipmentAPIstr == null || equipmentAPIJSON == null || equipmentAPIJSON == "") {
    return null;
  }
  infoProfile = equipmentAPIJSON["ArmoryProfile"];
  infoEquipment = equipmentAPIJSON["ArmoryEquipment"];
  isArkPassive = infoProfile["ArkPassive"]["IsArkPassive"];

  equipmentData2 += tooltipJSON(infoEquipment,"무기",false,true, isArkPassive)[0] + "\n";
  equipmentData2 += tooltipJSON(infoEquipment,"투구",false,true, isArkPassive)[0] + "\n";
  equipmentData2 += tooltipJSON(infoEquipment,"상의",false,true, isArkPassive)[0] + "\n";
  equipmentData2 += tooltipJSON(infoEquipment,"하의",false,true, isArkPassive)[0] + "\n";
  equipmentData2 += tooltipJSON(infoEquipment,"장갑",false,true, isArkPassive)[0] + "\n";
  equipmentData2 += tooltipJSON(infoEquipment,"어깨",false,true, isArkPassive)[0] + "\n";
  equipmentData2 += "평균 품질: " 
  + Math.round(((tooltipJSON(infoEquipment,"무기",false,true, isArkPassive)[2] 
  + tooltipJSON(infoEquipment,"투구",false,true, isArkPassive)[2] 
  + tooltipJSON(infoEquipment,"상의",false,true, isArkPassive)[2]
  + tooltipJSON(infoEquipment,"하의",false,true, isArkPassive)[2]
  + tooltipJSON(infoEquipment,"장갑",false,true, isArkPassive)[2]
  + tooltipJSON(infoEquipment,"어깨",false,true, isArkPassive)[2])/6)*10)/10;
  equipmentData2 += "\n초월 총합: " 
  + Math.round(tooltipJSON(infoEquipment,"무기",false,true, isArkPassive)[5] 
  + tooltipJSON(infoEquipment,"투구",false,true, isArkPassive)[5]
  + tooltipJSON(infoEquipment,"상의",false,true, isArkPassive)[5]
  + tooltipJSON(infoEquipment,"하의",false,true, isArkPassive)[5]
  + tooltipJSON(infoEquipment,"장갑",false,true, isArkPassive)[5]
  + tooltipJSON(infoEquipment,"어깨",false,true, isArkPassive)[5]);
  equipmentData2 += "\n\n" + "< 엘릭서 >" + "\n";
  equipmentData2 += tooltipJSON(infoEquipment,"투구",true,true, isArkPassive)[0];
  equipmentData2 += tooltipJSON(infoEquipment,"상의",true,true, isArkPassive)[0];
  equipmentData2 += tooltipJSON(infoEquipment,"하의",true,true, isArkPassive)[0];
  equipmentData2 += tooltipJSON(infoEquipment,"장갑",true,true, isArkPassive)[0];
  equipmentData2 += tooltipJSON(infoEquipment,"어깨",true,true, isArkPassive)[0];
  equipmentData2 += "엘릭서 합: " 
  + (tooltipJSON(infoEquipment,"투구",true,true, isArkPassive)[1] 
  + tooltipJSON(infoEquipment,"상의",true,true, isArkPassive)[1]
  + tooltipJSON(infoEquipment,"하의",true,true, isArkPassive)[1]
  + tooltipJSON(infoEquipment,"장갑",true,true, isArkPassive)[1]
  + tooltipJSON(infoEquipment,"어깨",true,true, isArkPassive)[1]);

  equipmentData = equipmentData2.replace(/Lv./gi,"");
  // return tooltipJSON(equipmentAPIJSON,"투구",false,true)[3] + "==" + tooltipJSON(equipmentAPIJSON,"투구",true,true)[4];
  return equipmentData;
}

// !악세 가공
function Accessories(_urlArr){
  var acceAPIJSON = getAPI(_urlArr[0]);
  var infoProfile = "";
  var infoEngraving = "";
  var infoEquipment = "";
  var accessoriesData = "";
  var accessoriesData2 = "";
  var _engTooltipJSON = "";
  var isArkPassive = false;

  // API 결과 Null 인 경우
  var acceAPIstr = JSON.stringify(acceAPIJSON);
  if (acceAPIstr == null || acceAPIJSON == null  || acceAPIJSON == "") {
    return null;
  }

  infoProfile = acceAPIJSON["ArmoryProfile"];
  infoEngraving = acceAPIJSON["ArmoryEngraving"];
  infoEquipment = acceAPIJSON["ArmoryEquipment"];
  isArkPassive = infoProfile["ArkPassive"]["IsArkPassive"];

  if(isArkPassive == false){
    // 장착 각인
    for (var i = 0; i < infoEngraving["Engravings"].length;  i++) {
      var test = JSON.stringify(infoEngraving["Engravings"][i]["Tooltip"]);
      var test1 = test.replace(/\\/gi, "");
      var test2 = test1.replace(/rn/gi, "");
      var test3 = test2.replace(/"Element_000": { "type":/gi, "},{ \"type\":");
      var test4 = test3.replace(/"Element_001": { "type":/gi, "{ \"type\":");
      var test5 = test4.replace(/"Element_002": { "type":/gi, "{ \"type\":");
      var test6 = test5.replace(/"Element_003": { "type":/gi, "{ \"type\":");
      var test7 = test6.replace(/"Element_004": { "type":/gi, "{ \"type\":");
      var test8 = test7.replace(/"Element_005": { "type":/gi, "{ \"type\":");
      var test9 = test8.replace(/"Element_006": { "type":/gi, "{ \"type\":");
      var test10 = test9.replace(/"Element_007": { "type":/gi, "{ \"type\":");
      var test11 = test10.replace(/"{ },/gi, "[");
      var test12 = test11.replace(/}"/gi, "]");
      _engTooltipJSON = JSON.parse(test12);
      for(var j = 0; j < _engTooltipJSON.length; j++){
        if(_engTooltipJSON[j]["type"] == "NameTagBox"){
          accessoriesData2 += _engTooltipJSON[j]["value"] + " ";
        }
        if(_engTooltipJSON[j]["type"] == "EngraveSkillTitle"){
          var useEng = _engTooltipJSON[j]["value"]["leftText"].split("+");
          var engPoint = useEng[1];
          accessoriesData2 += engPoint + " ";
        }
      }
    }
    accessoriesData2 += "\n";
  }

  accessoriesData2 += tooltipJSON(infoEquipment,"목걸이",false,false,isArkPassive)[0];
  accessoriesData2 += tooltipJSON(infoEquipment,"귀걸이",false,false,isArkPassive)[0];
  accessoriesData2 += tooltipJSON(infoEquipment,"반지",false,false,isArkPassive)[0];
  accessoriesData2 += tooltipJSON(infoEquipment,"어빌리티 스톤",false,false,isArkPassive)[0];
  accessoriesData2 += "\n" + "평균 품질: "  
  + Math.round(((tooltipJSON(infoEquipment,"목걸이",false,false,isArkPassive)[2]
  + tooltipJSON(infoEquipment,"귀걸이",false,false,isArkPassive)[2]
  + tooltipJSON(infoEquipment,"반지",false,false,isArkPassive)[2])/5)*10)/10;

  accessoriesData2 += tooltipJSON(infoEquipment,"팔찌",false,false,isArkPassive)[0];

  var accessoriesData3 = accessoriesData2.replace("고대 팔찌\n","고대 팔찌");
  accessoriesData = accessoriesData3.replace(/\+/gi,"");
  return accessoriesData;
}

// !각인 가공
function Engravings(_urlArr){
  var engravingsAPIJSON = getAPI(_urlArr[0]);
  var infoProfile = "";
  var infoEngraving = "";
  var engraving = "";
  var engraving2 = "";
  var isArkPassive = false;

  infoProfile = engravingsAPIJSON["ArmoryProfile"];
  infoEngraving = engravingsAPIJSON["ArmoryEngraving"];
  isArkPassive = infoProfile["ArkPassive"]["IsArkPassive"];

  // API 결과 Null 인 경우
  var engravingAPIstr = JSON.stringify(engravingsAPIJSON);
  if (engravingAPIstr == null || engravingsAPIJSON == null || engravingsAPIJSON == "") {
    return null;
  }

  // 각인
  if(isArkPassive == false){
    for(var i=0; i<infoEngraving["Effects"].length; i++){
      var engName = infoEngraving["Effects"][i]["Name"];
      engraving2 += engName + "\n";
    }
  }
  else{
    for(var i=0; i<infoEngraving["ArkPassiveEffects"].length; i++){
      var arkEngName = infoEngraving["ArkPassiveEffects"][i]["Name"];
      var arkEngGrade = infoEngraving["ArkPassiveEffects"][i]["Grade"];
      var arkEngGradeLv = infoEngraving["ArkPassiveEffects"][i]["Level"];

      engraving2 += "[" + arkEngGrade + "] " + arkEngName + "Lv." + arkEngGradeLv + "\n";
    }
    engraving2 += "\n스톤\n";
    for(var j=0; j<infoEngraving["ArkPassiveEffects"].length; j++){
      var _arkEngName = infoEngraving["ArkPassiveEffects"][j]["Name"];
      var arkEngStoneLv = infoEngraving["ArkPassiveEffects"][j]["AbilityStoneLevel"];
      if(arkEngStoneLv != null){
        engraving2 += _arkEngName + "Lv." + arkEngStoneLv + "\n";
      }
    }
  }

  engraving = engraving2.slice(0,engraving2.length -1);
  return engraving;
}

// !내실 가공
function Collectibles(_urlArr){
  var profileAPIJSON = getAPI(_urlArr[0]);
  var collectiblesAPIJSON = getAPI(_urlArr[1]);
  var data = "";
  var data1 = "";

  // API 결과 Null 인 경우
  var profileAPIstr = JSON.stringify(profileAPIJSON);
  var collectiblesAPIstr = JSON.stringify(collectiblesAPIJSON);
  if (collectiblesAPIstr == null || collectiblesAPIJSON == null || profileAPIstr == null || profileAPIJSON == null || collectiblesAPIJSON == "" || profileAPIJSON == "") {
    return null;
  }

  data1 += "템/원/전/영: " + profileAPIJSON["ItemAvgLevel"].slice(0, profileAPIJSON["ItemAvgLevel"].length -3) + "/" + profileAPIJSON["ExpeditionLevel"] + "/"  + profileAPIJSON["CharacterLevel"] + "/" + profileAPIJSON["TownLevel"];
  data1 += "\n스포: " + profileAPIJSON["UsingSkillPoint"] + " / " + profileAPIJSON["TotalSkillPoint"] + "\n";
  data1 += "\n< 성향 >\n";
  for(var i=0; i<profileAPIJSON["Tendencies"].length; i++){
    data1 += profileAPIJSON["Tendencies"][i]["Type"] + ": " + profileAPIJSON["Tendencies"][i]["Point"] + " ";
    if(i==1){
      data1 += "\n"
    }
  }
  
  data1 += "\n\n< 수집품 >\n";
  for(var i=0; i<collectiblesAPIJSON.length; i++){
    data1 += collectiblesAPIJSON[i]["Type"] + ": " + collectiblesAPIJSON[i]["Point"] + " ";
  }
  var data2 = data1.replace("모코코 씨앗", "모코코");
  var data3 = data2.replace("섬의 마음", "섬마");
  var data4 = data3.replace("위대한 미술품", "\n미술품");
  var data5 = data4.replace("거인의 심장", "거심");
  var data6 = data5.replace("이그네아의 징표", "\n이그네아");
  var data7 = data6.replace("항해 모험물", "모험물");
  var data8 = data7.replace("세계수의 잎", "\n세계수");
  var data9 = data8.replace("오르페우스의 별", "별");
  var data10 = data9.replace("기억의 오르골", "\n오르골");
  var data11 = data10.replace("크림스네일의 해도", "해도");

  data += data11;
  return data;
}

// !가격 가공
function searchMarket(_command, _urlArr, searchName){
  var marketData = "";
  var _marketData = "";
  var sort = "CURRENT_MIN_PRICE";
  var _categoryCode = makeJSONParam(_command)[0];
  var itemGrade = makeJSONParam(_command)[1];
  var characterClass = makeJSONParam(_command)[2];
  var sortCondition = makeJSONParam(_command)[3];
  var json = {"Sort": sort, "CategoryCode": _categoryCode, "CharacterClass": characterClass, "ItemTier": 0, "ItemGrade": itemGrade, "ItemName": searchName, "PageNo": 0, "SortCondition": sortCondition};
  var marketAPIJSON = postMarket(_urlArr, json);
  
  // API 결과 Null 인 경우
  var marketAPIstr = JSON.stringify(marketAPIJSON);
  if (marketAPIstr == null || marketAPIJSON == null || marketAPIJSON == "") {
    return null;
  }

  var marketItem = marketAPIJSON["Items"];
  _marketData += "등급 / 전날평균가 / 최저가 / 이름\n"
  for(var i=0; i<marketItem.length; i++){
    _marketData += marketItem[i]["Grade"] + " / " + marketItem[i]["YDayAvgPrice"] + " / " + marketItem[i]["CurrentMinPrice"] + " / " + marketItem[i]["Name"] + "\n";
  }
  
  marketData = _marketData.slice(0,_marketData.length-1);
  return marketData;
}

// !유각
function searchEngravis(_urlArr){
  var marketData = "";
  var _marketData = "";
  var sort = "CURRENT_MIN_PRICE";
  var json = {"Sort": sort, "CategoryCode": 40000, "CharacterClass": "", "ItemTier": 0, "ItemGrade": "", "ItemName": "각인", "PageNo": 0, "SortCondition": "DESC"};
  var marketAPIJSON = postMarket(_urlArr, json);
  
  // API 결과 Null 인 경우
  var marketAPIstr = JSON.stringify(marketAPIJSON);
  if (marketAPIstr == null || marketAPIJSON == null || marketAPIJSON == "") {
    return null;
  }

  var marketItem = marketAPIJSON["Items"];
  _marketData += "등급 / 전날평균가 / 최저가 / 이름\n"
  for(var i=0; i<marketItem.length; i++){
    _marketData += marketItem[i]["Grade"] + " / " + Math.round(marketItem[i]["YDayAvgPrice"]) + " / " + marketItem[i]["CurrentMinPrice"] + " / " + marketItem[i]["Name"] + "\n";
  }
  
  marketData = _marketData.slice(0,_marketData.length-1).replace(/ 각인서/g, "");
  return marketData;
}

// !가격 JSON 코드 !등급직업분류정렬가격
function makeJSONParam(input){
  var data = [];
  var _categoryCode = 0;
  var _itemGrade = "";
  var _characterClass = "";
  var _sortCondition = "";

  // 분류
  if((input.indexOf("아바타") != "-1")){ _categoryCode = 20000; }
  else if((input.indexOf("각인") != "-1")){ _categoryCode = 40000; }
  else if((input.indexOf("재료") != "-1")){ _categoryCode = 50000; }
  else if((input.indexOf("배템") != "-1")){ _categoryCode = 60000; }
  else if((input.indexOf("요리") != "-1")){ _categoryCode = 70000; }
  else if((input.indexOf("생활") != "-1")){ _categoryCode = 90000; }
  else if((input.indexOf("모험") != "-1")){ _categoryCode = 100000; }
  else if((input.indexOf("항해") != "-1")){ _categoryCode = 110000; }
  else if((input.indexOf("펫") != "-1")){ _categoryCode = 140000; }
  else if((input.indexOf("탈것") != "-1")){ _categoryCode = 160000; }
  else if((input.indexOf("기타") != "-1")){ _categoryCode = 170000; }
  else{ _categoryCode = 40000; }

  // 등급
  if((input.indexOf("일반") != "-1")){ _itemGrade = "일반"; }
  else if((input.indexOf("고급") != "-1")){ _itemGrade = "고급"; }
  else if((input.indexOf("희귀") != "-1")){ _itemGrade = "희귀"; }
  else if((input.indexOf("영웅") != "-1")){ _itemGrade = "영웅"; }
  else if((input.indexOf("전설") != "-1")){ _itemGrade = "전설"; }
  else if((input.indexOf("유물") != "-1")){ _itemGrade = "유물"; }
  else if((input.indexOf("고대") != "-1")){ _itemGrade = "고대"; }
  else if((input.indexOf("에스더") != "-1")){ _itemGrade = "에스더"; }
  else{ _itemGrade = ""; }

  // 클래스
  if((input.indexOf("버서커") != "-1")){ _characterClass = "버서커"; }
  else if((input.indexOf("디트") != "-1")){ _characterClass = "디스트로이어"; }
  else if((input.indexOf("인파") != "-1")){ _characterClass = "인파이터"; }
  else if((input.indexOf("기공") != "-1")){ _characterClass = "기공사"; }
  else if((input.indexOf("창술") != "-1")){ _characterClass = "창술사"; }
  else if((input.indexOf("스커") != "-1")){ _characterClass = "스트라이커"; }
  else if((input.indexOf("블레") != "-1")){ _characterClass = "블레이드"; }
  else if((input.indexOf("데모닉") != "-1")){ _characterClass = "데모닉"; }
  else if((input.indexOf("리퍼") != "-1")){ _characterClass = "리퍼"; }
  else if((input.indexOf("호크") != "-1")){ _characterClass = "호크아이"; }
  else if((input.indexOf("데헌") != "-1")){ _characterClass = "데빌헌터"; }
  else if((input.indexOf("블래") != "-1")){ _characterClass = "블래스터"; }
  else if((input.indexOf("워로드") != "-1")){ _characterClass = "워로드"; }
  else if((input.indexOf("스카") != "-1")){ _characterClass = "스카우터"; }
  else if((input.indexOf("건슬") != "-1")){ _characterClass = "건슬링어"; }
  else if((input.indexOf("도화가") != "-1")){ _characterClass = "도화가"; }
  else if((input.indexOf("기상") != "-1")){ _characterClass = "기상술사"; }
  else if((input.indexOf("홀나") != "-1")){ _characterClass = "홀리나이트"; }
  else if((input.indexOf("슬레") != "-1")){ _characterClass = "슬레이어"; }
  else if((input.indexOf("알카") != "-1")){ _characterClass = "아르카나"; }
  else if((input.indexOf("서머너") != "-1")){ _characterClass = "서머너"; }
  else if((input.indexOf("바드") != "-1")){ _characterClass = "바드"; }
  else if((input.indexOf("소서") != "-1")){ _characterClass = "소서리스"; }
  else if((input.indexOf("배마") != "-1")){ _characterClass = "배틀마스터"; }
  else{ _characterClass = ""; }

  // 가격순
  if((input.indexOf("높은순") != "-1")){ _sortCondition = "DESC"; }
  else if((input.indexOf("낮은순") != "-1")){ _sortCondition = "ASC"; }
  else { _sortCondition = ""; }

  data.push(_categoryCode);
  data.push(_itemGrade);
  data.push(_characterClass);
  data.push(_sortCondition);

  return data;
}
// !섬
function Island(_urlArr) {
  var islandAPIJSON = getAPI(_urlArr);
  var data = "";
  var uniqueItems = {}; // 중복된 값 제거를 위한 객체
  // 현재 날짜와 시간을 UTC로 가져오기
  var now = new Date();

  // 한국 표준시 (UTC+9)를 반영한 시간을 얻기 위해 시간 보정
  var offset = 9 * 60; // UTC+9는 9시간 차이, 분 단위로 변환
  var localTime = new Date(now.getTime() + offset * 60 * 1000);

  // 날짜를 'YYYY-MM-DD' 형식으로 포맷팅
  var year = localTime.getUTCFullYear();
  var month = String(localTime.getUTCMonth() + 1).padStart(2, '0'); // 월은 0부터 시작하므로 +1
  var day = String(localTime.getUTCDate()).padStart(2, '0'); // 날짜
  var today = year + "-" + month + "-" + day;

  // 현재 요일과 시간을 확인
  var dayOfWeek = localTime.getUTCDay();
  var hours = localTime.getUTCHours();

  // 오전과 오후 데이터 구분을 위한 변수
  var morningData = "- 오전 -\n";
  var afternoonData = "- 오후 -\n";

  // API 결과 Null 인 경우
  var islandAPIstr = JSON.stringify(islandAPIJSON);
  if (islandAPIstr == null || islandAPIJSON == null || islandAPIJSON == "") {
      return null;
  }

  for (var i = 0; i < islandAPIJSON.length; i++) {
      if (islandAPIJSON[i]["CategoryName"] == "모험 섬") {
          var rewardItems = islandAPIJSON[i]["RewardItems"][0];
          for (var j = 0; j < rewardItems["Items"].length; j++) {
              var startTimes = rewardItems["Items"][j]["StartTimes"];
              var contentsName = islandAPIJSON[i]["ContentsName"];
              var itemName = rewardItems["Items"][j]["Name"];
              if (Array.isArray(startTimes)) {
                  for (var k = 0; k < startTimes.length; k++) {
                      var startTime = startTimes[k];
                      var date = startTime.split("T")[0];
                      if (date === today && !uniqueItems[contentsName]) {
                          var startHour = parseInt(startTime.split("T")[1].split(":")[0], 10);
                          if (dayOfWeek === 0 || dayOfWeek === 6) { // 일요일(0) 또는 토요일(6)
                              if (startHour < 15) {
                                  if (itemName.includes('카드')) {
                                      itemName = '카드';
                                  } else if (itemName.includes('주화')) {
                                      itemName = '주화';
                                  }
                                  morningData += contentsName + " - " + itemName + "\n";
                              } else {
                                  if (itemName.includes('카드')) {
                                      itemName = '카드';
                                  } else if (itemName.includes('주화')) {
                                      itemName = '주화';
                                  }
                                  afternoonData += contentsName + " - " + itemName + "\n";
                              }
                            // 오전과 오후 데이터를 합치기
                            data = morningData + "\n" + afternoonData;
                          } else {
                              if (itemName.includes('카드')) {
                                  itemName = '카드';
                              } else if (itemName.includes('주화')) {
                                  itemName = '주화';
                              }
                              data += contentsName + " - " + itemName + "\n";
                          }
                          uniqueItems[contentsName] = true;
                      }
                  }
              }
          }
      }
  }

  // 추가된 항목이 있으면 출력에 추가
  var additionalItems = "";
  for (var i = 0; i < islandAPIJSON.length; i++) {
      if (islandAPIJSON[i]["CategoryName"] == "모험 섬") {
          var startTimes = islandAPIJSON[i]["StartTimes"];
          if (Array.isArray(startTimes)) {
              for (var j = 0; j < startTimes.length; j++) {
                  var startTime = startTimes[j];
                  var date = startTime.split("T")[0];
                  if (date === today) {
                      var contentsName = islandAPIJSON[i]["ContentsName"];
                      if (!uniqueItems[contentsName]) {
                          additionalItems += contentsName + " - ???\n";
                          uniqueItems[contentsName] = true;
                      }
                  }
              }
          }
      }
  }
  // 추가된 항목이 있으면 출력에 추가
  if (additionalItems !== "") {
      data += additionalItems;
  }

  // 마지막 개행 문자 제거
  if (data.endsWith("\n")) {
      data = data.slice(0, -1);
  }
  return data;
}

// Data 가공
function checkInputForData(_command, _urlArr, _searchName){
  var resultData = "";

  switch (_command) {
    case "!배럭":
      resultData = Characters(_urlArr);
        break;
    case "!부캐":
      resultData = Characters(_urlArr);
        break;
    case "!ㅂㅋ":
      resultData = Characters(_urlArr);
        break;
    case "!ㅂㄹ":
      resultData = Characters(_urlArr);
        break;
    case "!원정대":
      resultData = Characters(_urlArr);
        break;
    case "!ㅇㅈㄷ":
      resultData = Characters(_urlArr);
        break;
    case "!정보":
      resultData = Info(_urlArr, _searchName);
        break;
    case "!보석":
      resultData = Gems(_urlArr);
        break;
    case "!아바타":
        break;
    case "!스킬":
      resultData = Skills(_urlArr);
        break;
    case "!장비":
      resultData = Equipemnt(_urlArr, _searchName);
        break;
    case "!악세":
      resultData = Accessories(_urlArr);
        break;
    case "!각인":
      resultData = Engravings(_urlArr);
        break;
    case "!내실":
      resultData = Collectibles(_urlArr);
        break;
    case "!섬":
      resultData = Island(_urlArr);
        break;
    case "!유각":
      resultData = searchEngravis(_urlArr);
        break;
    case "!ㅅ":
      resultData = Island(_urlArr);
        break;
    case "!ㅇㄱ":
      resultData = searchEngravis(_urlArr);
        break;    
    case (_command.indexOf("가격") != "-1" && _command.indexOf("!") == 0) ? _command : "입1력2방3지4방5지6" :
      resultData = searchMarket(_command, _urlArr, _searchName);
        break;
  }
  return resultData;
}

// Null Data 처리
function nullData(_command){
  var _nullData = "";

  switch (_command) {
    case "!배럭":
      _nullData = "안함";
        break;
    case "!부캐":
      _nullData = "안함";
        break;
    case "!ㅂㅋ":
      _nullData = "안함";
        break;
    case "!ㅂㄹ":
      _nullData = "안함";
        break;
    case "!원정대":
      _nullData = "안함";
        break;
    case "!ㅇㅈㄷ":
      _nullData = "안함";
        break;
    case "!정보":
      _nullData = "안함";
        break;
    case "!보석":
      _nullData = "쌀";
        break;
    case "!아바타":
        break;
    case "!스킬":
      _nullData = "평타맨";
        break;
    case "!장비":
      _nullData = "알몸";
        break;
    case "!악세":
      _nullData = "그지";
        break;
    case "!각인":
      _nullData = "응애";
        break;
    case "!내실":
      _nullData = "응애";
        break;
    case "!유각":
      _nullData = "장사안함";
        break;        
    case (_command.indexOf("가격") != "-1" && _command.indexOf("!") == 0) ? _command : "입1력2방3지4방5지6" :
      _nullData = "안팜";
        break;
  }
  return _nullData;
}

// 다중 URL 생성
function checkInputForURL(_command, searchName){
  var _urlArr = [];

  // 가격 검색
  if(_command.indexOf("가격") != "-1" && _command.indexOf("!") == 0){
    _command = true;
  }

  switch (_command) {
    case "!배럭":
      _urlArr.push(makeURIget(0,0,searchName));
        break;
    case "!부캐":
      _urlArr.push(makeURIget(0,0,searchName));
        break;
    case "!ㅂㅋ":
      _urlArr.push(makeURIget(0,0,searchName));
        break;
    case "!ㅂㄹ":
      _urlArr.push(makeURIget(0,0,searchName));
        break;
    case "!원정대":
      _urlArr.push(makeURIget(0,0,searchName));
        break;
    case "!ㅇㅈㄷ":
      _urlArr.push(makeURIget(0,0,searchName));
        break;
    case "!정보":
      _urlArr.push(makeURIget(1,14,searchName));
        break;
    case "!보석":
      _urlArr.push(makeURIget(1,7,searchName));
        break;
    case "!아바타":
      // _urlArr.push(makeURIget(1,3,searchName));
        break;
    case "!스킬":
      _urlArr.push(makeURIget(1,4,searchName));
        break;
    case "!장비":
      _urlArr.push(makeURIget(1,14,searchName));
        break;
    case "!악세":
      _urlArr.push(makeURIget(1,14,searchName));
        break;
    case "!각인":
      _urlArr.push(makeURIget(1,14,searchName));
        break;
    case "!내실":
      _urlArr.push(makeURIget(1,1,searchName));
      _urlArr.push(makeURIget(1,9,searchName));
        break;
    case "!섬":
      _urlArr.push(makeURIget(5,13,""));
        break;
    case "!유각":
      _urlArr.push(makeURIpost(4,12));
        break;
    case "!ㅅ":
      _urlArr.push(makeURIget(5,13,""));
        break;
    case "!ㅇㄱ":
      _urlArr.push(makeURIpost(4,12));
        break;
    case true:
      _urlArr.push(makeURIpost(4,12));
        break;
  }
  return _urlArr;
}

// get URL 생성
function makeURIget (_urlF, _urlB, searchName) {
  var _url = "";
  _url = apiURLF[_urlF] + searchName + apiURLB[_urlB];

  return _url;
}

// post URL 생성
function makeURIpost (_urlF, _urlB) {
  var _url = "";
  _url = apiBaseURL + apiURLF[_urlF] + apiURLB[_urlB];

  return _url;
}

// getAPI
function getAPI (_url){
  var data = "";
  try {
    var res = org.jsoup.Jsoup.connect(apiBaseURL + _url)
    .header("accept", "application/json") 
    .header("authorization", apiKey)
    .ignoreHttpErrors(true)
    .ignoreContentType(true)
    .get().text();
    // JSON 문자열을 객체로 반환
    if(res == "" || res == null){
      data = res;
    }
    else {
      data = JSON.parse(res);
    }

    return data;
  } catch (e) {
    return e;  
  }
}

// postAPI 마켓용
function postMarket(_urlArr, _json) { 
  var data = "";
  try { 
      /*
      .data("Sort", "GRADE")
      .data("CategoryCode", categoryCode)
      .data("CharacterClass", "")
      .data("ItemTier", 0)
      .data("ItemGrade", "")
      .data("ItemName", item)
      .data("PageNo", 0)
      .data("SortCondition", "ASC")            
      .ignoreContentType(true) 
      .ignoreHttpErrors(true) 
      .post().text(); 
      */
      var json = _json;
      var url = _urlArr;
      // "https://developer-lostark.game.onstove.com/markets/items";
      var res = org.jsoup.Jsoup.connect(url)
          .header("accept", "application/json")
          .header("authorization", apiKey)
          .header("Content-Type", "application/json")
          .requestBody(JSON.stringify(json))    
          .ignoreHttpErrors(true)        
          .ignoreContentType(true) 
          .post().text();        
    // JSON 문자열을 객체로 반환
    if(res == "" || res == null){
      data = res;
    }
    else {
      data = JSON.parse(res);
    }
      return data;
  } catch (e) { 
      return e;
  } 
};

//아래 4개의 메소드는 액티비티 화면을 수정할때 사용됩니다.
function onCreate(savedInstanceState, activity) {
  var textView = new android.widget.TextView(activity);
  textView.setText("Hello, World!");
  textView.setTextColor(android.graphics.Color.DKGRAY);
  activity.setContentView(textView);
}

function onStart(activity) {}

function onResume(activity) {}

function onPause(activity) {}

function onStop(activity) {}

function onNotificationPosted(sbn, sm) {
  var packageName = sbn.getPackageName();
  if (!packageName.startsWith("com.kakao.tal")) return;
  var actions = sbn.getNotification().actions;
  if (actions == null) return;
  var userId = sbn.getUser().hashCode();
  for (var n = 0; n < actions.length; n++) {
      var action = actions[n];
      if (action.getRemoteInputs() == null) continue;
      var bundle = sbn.getNotification().extras;

      var msg = bundle.get("android.text").toString();
      var sender = bundle.getString("android.title");
      var room = bundle.getString("android.subText");
      if (room == null) room = bundle.getString("android.summaryText");
      var isGroupChat = room != null;
      if (room == null) room = sender;
      var replier = new com.xfl.msgbot.script.api.legacy.SessionCacheReplier(packageName, action, room, false, "");
      var icon = bundle.getParcelableArray("android.messages")[0].get("sender_person").getIcon().getBitmap();
      var image = bundle.getBundle("android.wearable.EXTENSIONS");
      if (image != null) image = image.getParcelable("background");
      var imageDB = new com.xfl.msgbot.script.api.legacy.ImageDB(icon, image);
      com.xfl.msgbot.application.service.NotificationListener.Companion.setSession(packageName, room, action);
      if (this.hasOwnProperty("responseFix")) {
          responseFix(room, msg, sender, isGroupChat, replier, imageDB, packageName, userId != 0);
      }
  }
}


  // !가격 xxx
  // !비싼전각
  // !아바타

function testJSON(replier, isElixir, isEquip, msg) {
  var type = msg.substr(6,msg.length);
  var _equipmentAPIJSON = getAPI("/armories/characters/"+"방울토마토라면"+"/equipment")
  var data = "";
  var element_num = "";
  var elixirSum = 0;
  var qualityValue = 0;
  var transcendenceSum = 0;
  var setEffect = "";
  var elixirEffect = "";
  for (var i = 0; i < _equipmentAPIJSON.length;  i++) {
    if(_equipmentAPIJSON[i]["Type"] == type){
      var test = JSON.stringify(_equipmentAPIJSON[i]["Tooltip"]);
      var test1 = test.replace(/\\/gi, "");
      var test2 = test1.replace(/rn/gi, "");
      var test3 = test2.replace(/"Element_000": { "type":/gi, "},{ \"type\":");
      var test4 = test3.replace(/"Element_001": { "type":/gi, "{ \"type\":");
      var test5 = test4.replace(/"Element_002": { "type":/gi, "{ \"type\":");
      var test6 = test5.replace(/"Element_003": { "type":/gi, "{ \"type\":");
      var test7 = test6.replace(/"Element_004": { "type":/gi, "{ \"type\":");
      var test8 = test7.replace(/"Element_005": { "type":/gi, "{ \"type\":");
      var test9 = test8.replace(/"Element_006": { "type":/gi, "{ \"type\":");
      var test10 = test9.replace(/"Element_007": { "type":/gi, "{ \"type\":");
      var test11 = test10.replace(/"Element_008": { "type":/gi, "{ \"type\":");
      var test12 = test11.replace(/"Element_009": { "type":/gi, "{ \"type\":");
      var test13 = test12.replace(/"Element_010": { "type":/gi, "{ \"type\":");
      var test14 = test13.replace(/"Element_011": { "type":/gi, "{ \"type\":");
      var test15 = test14.replace(/"Element_012": { "type":/gi, "{ \"type\":");
      var test16 = test15.replace(/"Element_013": { "type":/gi, "{ \"type\":");
      var test17 = test16.replace(/"Element_014": { "type":/gi, "{ \"type\":");
      var test18 = test17.replace(/"Element_015": { "type":/gi, "{ \"type\":");
      var test19 = test18.replace(/"Element_016": { "type":/gi, "{ \"type\":");
      var test20 = test19.replace(/"Element_017": { "type":/gi, "{ \"type\":");
      var test21 = test20.replace(/"Element_018": { "type":/gi, "{ \"type\":");
      var test22 = test21.replace(/"{ },/gi, "[");
      var test23 = test22.replace(/}"/gi, "]");
      // var _equipTooltipJSON = JSON.parse(test22);
      // var testdata = "test=";
      // //장비
      // if(isEquip == true){
      //   if(isElixir == false){
      //     for(var j = 0; j < _equipTooltipJSON.length; j++){
      //       // 재련수치
      //       if(_equipTooltipJSON[j]["type"] == "NameTagBox"){
      //         var equipment = _equipTooltipJSON[j]["value"];
      //         data += type + ": " + equipment.slice(2, 4) + "[00";
      //       }
      //       // 상급 재련
      //       if(_equipTooltipJSON[j]["type"] == "SingleTextBox"){
      //         if(_equipTooltipJSON[j]["value"].indexOf("상급 재련") != "-1")
      //         {
      //           var modifiedString = data.slice(0, -2);
      //           data = modifiedString;
      //           var startIndex = _equipTooltipJSON[j]["value"].indexOf("[상급 재련]");
      //           var endIndex = _equipTooltipJSON[j]["value"].indexOf("단계") + 2; 
      //           var extractedString = _equipTooltipJSON[j]["value"].slice(startIndex + "[상급 재련] ".length, endIndex - 2);
      //           if (extractedString.length === 1) {
      //             data += "0" + extractedString;
      //           }
      //           else if (extractedString.length === 2){
      //             data += "" + extractedString;
      //           }
      //         }
      //       }
      //       // 세트효과
      //       if(_equipTooltipJSON[j]["type"] == "ItemPartBox"){
      //         if(_equipTooltipJSON[j]["value"]["Element_000"].indexOf("세트") != "-1"){
      //           var set0 = _equipTooltipJSON[j]["value"]["Element_001"].substring(0,2);
      //           if(set0 == "장착"){
      //             data += "짱쎔";
      //           }else{
      //             data += "] " + set0 + " ";
      //           }
      //           setEffect = set0;
      //         }
      //       }
      //     }
      //     // 품질
      //     for(var j = 0; j < _equipTooltipJSON.length; j++){
      //       if(_equipTooltipJSON[j]["type"] == "ItemTitle"){
      //         data += "(" + _equipTooltipJSON[j]["value"]["qualityValue"] + ")" + " ";
      //         // if(type == "무기"){
      //         //   data += "\n";
      //         // }
      //         qualityValue += parseInt(_equipTooltipJSON[j]["value"]["qualityValue"]);
      //       }
      //     }
      //     // 초월
      //     for(var m = 0; m < _equipTooltipJSON.length; m++){
      //       if(_equipTooltipJSON[m]["type"] == "IndentStringGroup"){
      //         testdata += JSON.stringify(_equipTooltipJSON[m]["value"]);
      //         if(_equipTooltipJSON[m]["value"] == null){
      //           continue;
      //         }
      //         if(_equipTooltipJSON[m]["value"]["Element_000"]["topStr"].indexOf("초월") != "-1"){
      //           var transcendence = _equipTooltipJSON[m]["value"]["Element_000"]["topStr"];
      //           var startIndex = _equipTooltipJSON[m]["value"]["Element_000"]["topStr"].indexOf("[초월]");
      //           var extractedString = _equipTooltipJSON[m]["value"]["Element_000"]["topStr"].slice(startIndex + "[초월]".length).trim();
      //           data += extractedString;
      //           transcendenceSum += parseInt(transcendence.slice(transcendence.length-2,transcendence.length));
      //         }
      //         else{
      //           if(_equipTooltipJSON[m]["value"]["Element_000"]["topStr"].indexOf("엘릭서") != "-1"){}
      //           else if(_equipTooltipJSON[m]["value"]["Element_000"]["topStr"].indexOf("연성") != "-1"){}
      //           else if(_equipTooltipJSON[m]["value"]["Element_000"]["topStr"].indexOf("세트") != "-1"){
      //             // if(type != "무기"){
      //                 data += "\n";
      //             // }
      //           }
      //         }
      //       }
      //     }
      //   }
      //   // 엘릭서
      //   // else{
      //   //   for(var k = 0; k < _equipTooltipJSON.length; k++){
      //   //     if(_equipTooltipJSON[k]["type"] == "IndentStringGroup"){
      //   //       if(_equipTooltipJSON[k]["value"]["Element_000"]["contentStr"]["Element_000"]["bPoint"] == true){
      //   //         if(_equipTooltipJSON[k]["value"]["Element_000"]["contentStr"]["Element_000"]["contentStr"].indexOf("[") != "-1"){
      //   //           var contentStr1 = _equipTooltipJSON[k]["value"]["Element_000"]["contentStr"]["Element_000"]["contentStr"];
      //   //           var contentStr2 = contentStr1.slice(contentStr1.search("]")+2,contentStr1.search("Lv")+4);
      //   //           var elixirNum = contentStr1.slice(contentStr1.search("Lv")+3,contentStr1.search("Lv")+4);
      //   //           elixirSum += parseInt(elixirNum);
      //   //           data += type + ": " + contentStr2;
      //   //           if(Object.keys(_equipTooltipJSON[k]["value"]["Element_000"]["contentStr"]).length == 1){
      //   //             data += "\n";
      //   //           }
      //   //         }
      //   //         if(Object.keys(_equipTooltipJSON[k]["value"]["Element_000"]["contentStr"]).length > 1){
      //   //           if(_equipTooltipJSON[k]["value"]["Element_000"]["contentStr"]["Element_001"]["contentStr"].indexOf("[") != "-1"){
      //   //             var contentStr3 = _equipTooltipJSON[k]["value"]["Element_000"]["contentStr"]["Element_001"]["contentStr"];
      //   //             var contentStr4 = contentStr3.slice(contentStr3.search("]")+1,contentStr3.search("Lv")+4);
      //   //             var elixirNum = contentStr3.slice(contentStr3.search("Lv")+3,contentStr3.search("Lv")+4);
      //   //             elixirSum += parseInt(elixirNum);
      //   //             data += contentStr4 + "\n";
      //   //           }
      //   //         }
      //   //       }
      //   //     }
      //   //   }
      //   //   for(var k = 0; k < _equipTooltipJSON.length; k++){
      //   //     if(_equipTooltipJSON[k]["type"] == "IndentStringGroup"){
      //   //       if(_equipTooltipJSON[k]["value"]["Element_000"]["contentStr"]["Element_000"]["bPoint"] == true){
      //   //         if(_equipTooltipJSON[k]["value"]["Element_000"]["contentStr"]["Element_000"]["contentStr"].indexOf("단계 :") != "-1"){
      //   //           elixirEffect = _equipTooltipJSON[k]["value"]["Element_000"]["topStr"];
      //   //         }
      //   //       }
      //   //     }
      //   //   }
      //   // }

      // }
      //악세
      // else{
      //   for(var j = 0; j < _equipTooltipJSON.length; j++){
      //     // 등급 이름
      //     if(_equipTooltipJSON[j]["type"] == "ItemTitle"){
      //       var accessory = _equipTooltipJSON[j]["value"];
      //       if(accessory["leftStr0"].indexOf("이") != "-1"){
      //         data += accessory["leftStr0"].slice(0,accessory["leftStr0"].length -2);
      //       }
      //       else if(type == "팔찌"){
      //         data += "\n\n" + accessory["leftStr0"] + "\n";
      //       }
      //       else if(type == "반지"){
      //         data += accessory["leftStr0"].slice(0,accessory["leftStr0"].length -1);
      //       }
      //       else{
      //         data += accessory["leftStr0"];
      //       }
      //     }
      //     // 각인효과
      //     if(_equipTooltipJSON[j]["type"] == "IndentStringGroup"){
      //       var engrave00 = _equipTooltipJSON[j]["value"]["Element_000"]["contentStr"]["Element_000"]["contentStr"]
      //       var engrave01 = _equipTooltipJSON[j]["value"]["Element_000"]["contentStr"]["Element_001"]["contentStr"]
      //       var engrave1 = engrave00.slice(1,2);
      //       var engrave2 = engrave00.slice(engrave00.length-2,engrave00.length-1);
      //       var engrave3 = engrave01.slice(1,2);
      //       var engrave4 = engrave01.slice(engrave01.length-2,engrave01.length-1);
      //       var engrave5 = " " + engrave1 + engrave2 + " " + engrave3 + engrave4 + " ";
      //       data += engrave5;
      //     }
      //   }
      //   // 특성
      //   for(var j = 0; j < _equipTooltipJSON.length; j++){
      //     if(_equipTooltipJSON[j]["type"] == "ItemPartBox"){
      //       if(_equipTooltipJSON[j]["value"]["Element_000"] == "추가 효과"){
      //         var cha0 = _equipTooltipJSON[j]["value"]["Element_001"];
      //         var cha1 = cha0.replace(/치명 /gi,"치");
      //         var cha2 = cha1.replace(/특화 /gi,"특");
      //         var cha3 = cha2.replace(/신속 /gi,"신");
      //         var cha4 = cha3.replace(/제압 /gi,"제");
      //         var cha5 = cha4.replace(/인내 /gi,"인");
      //         var cha6 = cha5.replace(/숙련 /gi,"숙");
      //         data += cha6;
      //       }
      //     }
      //   }
      //   // 품질
      //   for(var j = 0; j < _equipTooltipJSON.length; j++){
      //     if(_equipTooltipJSON[j]["type"] == "ItemTitle"){
      //       if(type == "어빌리티 스톤" || type == "팔찌"){}
      //       else{
      //         data += "(" + _equipTooltipJSON[j]["value"]["qualityValue"] + ")" + "\n";
      //         qualityValue += parseInt(_equipTooltipJSON[j]["value"]["qualityValue"]);
      //       }
      //     }
      //   }
      //   // 팔찌효과
      //   if(type == "팔찌"){
      //     for(var j = 0; j < _equipTooltipJSON.length; j++){
      //       if(_equipTooltipJSON[j]["type"] == "ItemPartBox"){
      //         if(_equipTooltipJSON[j]["value"]["Element_000"] == "팔찌 효과"){
      //           var bracelet = _equipTooltipJSON[j]["value"]["Element_001"].replace(/\[/gi,"\n\[")
      //           var bracelet1 = bracelet.replace(/치명 \+/gi,"\n 치명 ");
      //           var bracelet2 = bracelet1.replace(/특화 \+/gi,"\n 특화 ");
      //           var bracelet3 = bracelet2.replace(/신속 \+/gi,"\n 신속 ");
      //           var bracelet4 = bracelet3.replace(/제압 \+/gi,"\n 제압 ");
      //           var bracelet5 = bracelet4.replace(/인내 \+/gi,"\n 인내 ");
      //           var bracelet6 = bracelet5.replace(/숙련 \+/gi,"\n 숙련 ");
      //           var bracelet7 = bracelet6.replace(/최대 생명력 \+/gi,"\n 최대 생명력 ");
      //           var bracelet8 = bracelet7.replace(/최대 마나 \+/gi,"\n 최대 마나 ");
      //           var bracelet9 = bracelet8.replace(/물리 방어력 \+/gi,"\n 물리 방어력 ");
      //           var bracelet10 = bracelet9.replace(/마법 방어력 \+/gi,"\n 마법 방어력 ");
      //           var bracelet11 = bracelet10.replace(/전투 중 생명력 회복량 \+/gi,"\n 전투 중 생명력 회복량 ");
      //           var bracelet12 = bracelet11.replace(/무기 공격력 \+/gi,"\n 무기 공격력 ");
      //           var bracelet13 = bracelet12.replace(/체력 \+/gi,"\n 체력 ");
      //           var bracelet14 = bracelet13.replace(/힘 \+/gi,"\n 힘 ");
      //           var bracelet15 = bracelet14.replace(/민첩 \+/gi,"\n 민첩 ");
      //           var bracelet16 = bracelet15.replace(/지능 \+/gi,"\n 지능 ");
      //           data += bracelet16
      //         }
      //       }
      //     }
      //   }
      // }
    }
  }
  replier.reply(test23);
  // replier.reply(testdata);
  return test22;
  // return [data, elixirSum, qualityValue, setEffect, elixirEffect]
}