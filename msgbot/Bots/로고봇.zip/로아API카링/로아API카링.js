const scriptName = "로아API카링";
/**
 * (string) room
 * (string) sender
 * (boolean) isGroupChat
 * (void) replier.reply(message)
 * (boolean) replier.reply(room, message, hideErrorToast = false) // 전송 성공시 true, 실패시 false 반환
 * (string) imageDB.getProfileBase64()
 * (string) packageName
 */

apiKey = "bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6IktYMk40TkRDSTJ5NTA5NWpjTWk5TllqY2lyZyIsImtpZCI6IktYMk40TkRDSTJ5NTA5NWpjTWk5TllqY2lyZyJ9.eyJpc3MiOiJodHRwczovL2x1ZHkuZ2FtZS5vbnN0b3ZlLmNvbSIsImF1ZCI6Imh0dHBzOi8vbHVkeS5nYW1lLm9uc3RvdmUuY29tL3Jlc291cmNlcyIsImNsaWVudF9pZCI6IjEwMDAwMDAwMDAxMDQyNDYifQ.LbWRJAb502GgmlQfzaTtjBimxBGYmIWfE9v4zemt7AVSAbZoKTKt6FsaP2sKtO8jAbgFnyfh5RM9YmnQg2hAA0K3jXMUCOkdMKnhjuH4bnVn0LXCWfRFJUWZrEpWvgyfNyCs_ZjrdzFzPMLtptOkGWIIP_BhEcZFRXQcVvGPzvW-GI_o4AZR5BSIPUv9Yg7RgD5NrGoQlxo1B_nwty7NXZ7Lxjrt-Ck2LOLjZVu3WNDTVjaymhDBR6hZEaaQdMCrCZLdz0eO2APrTwQJOCcfDYtIGOHYwBmepRAQCiASBKq3bGt65T2J6-1pnDNa9qkpMPh-QwahSagEWtIbmp3ybw";
apiBaseURL = "https://developer-lostark.game.onstove.com/";
apiURLF = ["/characters/", "/armories/characters/", "/auctions", "/guilds/rankings", "/markets"];
apiURLB = ["/siblings", "/profiles", "/equipment", "/avatars", "/combat-skills", "/engravings", "/cards", "/gems", "/colosseums", "/collectibles", "/options", "/items/", "/items"];

const { KakaoLinkClient } = require('kakaolink');
const Kakao = new KakaoLinkClient('c0d2d5a6da78d03cc4667cec3b4756a9', 'https://open.kakao.com/o/ssdOPG0e');
Kakao.login('rmsepskek02@gmail.com', 'wmrm13241423!');

var charaterName = "";
var arrNumF = 0;
var arrNumB = 0;
var url = "";
var resultAPI = "";
var resultData = "";
var output = "";
var kalingTpye = 0;
var usingKaling = false;

function responseFix(room, msg, sender, isGroupChat, replier, imageDB, packageName) {
  
  // if(room != "한용희"){
  //   return;
  // }

  if(msg == "123"){

  }
  // 출력
  replyData(room, msg, sender, isGroupChat, replier, imageDB, packageName);
}

// API URL 생성 & API 결과 출력
function replyData(room, msg, sender, isGroupChat, replier, imageDB, packageName){
  // 출력 초기화
  output = "";
  // 입력 값
  var input = msg.split(" ");
  // 입력 값 검사
  //// TODO 입력값 검사하는 함수를 만들자 Array로 명령어 담고 for문 돌려서 검사
  if (!msg.includes("!") || msg[0] != "!" || input[1] == "" || input[1] == null){ return; }
  // 닉네임
  charaterName = input[1];
  output += "< "+charaterName+" >"+"님의 정보"+"\n";
  // 입력값 검사 for URL
  checkInputForURL(input[0]);
  // URL 생성
  url = apiURLF[arrNumF]+charaterName+apiURLB[arrNumB];
  // API 호출
  resultAPI = getAPI(url);
  var _resultAPI = JSON.stringify(resultAPI);
  // 데이터 가공
  output += checkInputForData(input[0], resultAPI);

  // 결과 출력
  if (resultAPI == null || _resultAPI == null || checkInputForData(input[0], resultAPI) == null || checkInputForData(input[0], resultAPI) == "") { 
    output = ""; 
    output += checkInputForData(input[0], resultAPI);
    // 텍스트결과 출력
    replier.reply(output);
  }
  else{
    // 카카오링크 출력 
    if (usingKaling == true){
      checkTemplatesKakaolink(kalingTpye, room, output);
      replier.reply("카링");
    }
    // 텍스트 출력
    else {replier.reply(output);}
  }
}

// !스킬 가공
function Skills(_resultAPI){
  var skillsData = _resultAPI;
  var _skillsData = "";
  var skillFilterRune = [];

  // API 결과 Null 인 경우
  var resultAPI = JSON.stringify(_resultAPI);
  if (resultAPI == null || _resultAPI == null) {
    return "안함";
  }
  
  // 사용하는지 여부
  // 트포 사용 여부
  // 이름 아이콘 레벨 / 트포 사용여부 렙 아이콘? / 룬 이름 등급 아이콘?

  // 룬 장착 여부 == 사용 여부
  for (var i = 0; i < skillsData.length; i++){
    if(skillsData[i]["Rune"] != null){
      skillFilterRune.push(skillsData[i]);
    }
  }

  // 레벨 순 정렬
  var levelResult = skillFilterRune.sort((a,b) => {
    let x = parseInt(a.Level);
    let y = parseInt(b.Level);
    if (x < y) { return 1; }
    if (x > y) { return -1; }
    return 0;
  });

  for (var i = 0; i < levelResult.length; i++){
    _skillsData += "Lv"+levelResult[i]["Level"] +" "+levelResult[i]["Name"]+"\n"
                 +levelResult[i]["Icon"]+"\n";
    for (var j = 0; j < levelResult[i]["Tripods"].length; j++){
      if( levelResult[i]["Tripods"][j]["IsSelected"] == true ){
        var tripodsName = levelResult[i]["Tripods"][j]["Name"].split(" ")
        for(var k = 0; k < tripodsName.length; k++){
          if ( tripodsName.length < 2){ _skillsData += tripodsName[k].slice(0,2); }
          else{ _skillsData += tripodsName[k].slice(0,1); }
        }
        _skillsData += levelResult[i]["Tripods"][j]["Level"]+ " ";
      }
    }
    // _skillsData += "("+levelResult[i]["Rune"]["Grade"]+levelResult[i]["Rune"]["Name"]+")"+"\n"
    _skillsData += levelResult[i]["Rune"]["Name"]+"\n"
  }
  var _skillsData2 = _skillsData.slice(0, _skillsData.length - 1);
  return _skillsData2;
}

// !배럭 가공
function Characters(_resultAPI){
  var charactersData = _resultAPI;
  var _charactersData = "";

  // API 결과 Null 인 경우
  var resultAPI = JSON.stringify(_resultAPI);
  if (resultAPI == null || _resultAPI == null) {
    return "안함";
  }

  // 레벨 순 정렬
  var levelResult = charactersData.sort((a,b) => {
    let x = parseFloat(a.ItemMaxLevel.replace(/,/gi, "").toLowerCase());
    let y = parseFloat(b.ItemMaxLevel.replace(/,/gi, "").toLowerCase());
    if (x < y) { return 1; }
    if (x > y) { return -1; }
    return 0;
  });
  var maxLevelSerever = levelResult[0]["ServerName"];

  // 계정 서버 리스트 
  var serverNameArrTemp = [];
  var serverNameArr = [];
  for(var i = 0; i < charactersData.length; i++){
    var charactersServerName = charactersData[i]["ServerName"];
    serverNameArrTemp.push(charactersServerName);
  }
  for(var i = 0; i < serverNameArrTemp.length; i++){
    if(!serverNameArr.includes(serverNameArrTemp[i])){
      serverNameArr.push(serverNameArrTemp[i]);
    }
  }

  // 가장 렙이 높은 캐릭터의 서버 원정대
  var _charactersDataTemp = ""
  _charactersDataTemp += "["+maxLevelSerever+"]"+"\n";
  for(var i = 0; i < levelResult.length; i++){
    if (maxLevelSerever == levelResult[i]["ServerName"]){
      _charactersDataTemp += "Lv"+levelResult[i]["ItemMaxLevel"].replace(/,/gi, "")
                            +" ["+levelResult[i]["CharacterClassName"].substring(0,2)+"]"
                            +" "+levelResult[i]["CharacterName"]+"\n";
      
      if (i == 5){
        _charactersDataTemp += "#####G---O---L---D#####"+"\n";
      }
    }
  }

  // 다른 서버 원정대
  for(var i = 0; i < serverNameArr.length; i++){
    if (serverNameArr[i] != maxLevelSerever) {
      _charactersDataTemp += "["+serverNameArr[i]+"]"+"\n";
      for(var j = 0; j < levelResult.length; j++){
        if (serverNameArr[i] == levelResult[j]["ServerName"]){
          _charactersDataTemp += "Lv"+levelResult[j]["ItemMaxLevel"].replace(/,/gi, "")
                                +" ["+levelResult[j]["CharacterClassName"].substring(0,2)+"]"
                                +" "+levelResult[j]["CharacterName"]+"\n";
        }
      }
    }
  }

  var _charactersDataTemp2 = _charactersDataTemp.slice(0, _charactersDataTemp.length - 1);
  _charactersData = _charactersDataTemp2;
  return _charactersData;
}

// !보석 가공
function Gems(_resultAPI){
  var gemData = '{"GemsData" : [';

  // API 결과 Null 인 경우
  var resultAPI = JSON.stringify(_resultAPI);
  if (resultAPI == null || _resultAPI == null) {
    return "쌀";
  }

  for (var i = 0; i < _resultAPI["Gems"].length;  i++) {
    var slot = JSON.stringify(_resultAPI["Gems"][i]["Slot"]);
      for(var j = 0; j < _resultAPI["Effects"].length; j ++){
        var gemSlot = JSON.stringify(_resultAPI["Effects"][j]["GemSlot"]);
        if (slot == gemSlot){
          // 멸화 홍염
          var slotName =  JSON.stringify(_resultAPI["Gems"][i]["Name"]);
          var _slotName1 = slotName.replace(/의 보석/gi, "");
          var _slotName2 = _slotName1.replace(/레벨/gi, "");
          var _slotName3 = _slotName2.replace(/10 /gi, "10");
          // 렙
          var gemsLevel = JSON.stringify(_resultAPI["Gems"][i]["Level"]);
          // 스킬 이름
          var gemSlotName = JSON.stringify(_resultAPI["Effects"][j]["Name"]);
          // 이미지
          var gemImage = JSON.stringify(_resultAPI["Gems"][i]["Icon"]);
          gemData += '{"GemsName" : ' + _slotName3 + ',';
          gemData += '"GemsLevel" : ' + "\"" + gemsLevel + "\"" + ',';
          gemData += '"GemsImage" : ' + gemImage + ',';
          gemData += '"GemsEffect" : ' + gemSlotName + '},';
        }
      }
  }
  var gemsTemp = gemData.slice(0, gemData.length - 1);
  gemsTemp += ']}';
  // API 결과 JSON 반환
  var gemsJson = JSON.parse(gemsTemp);
  // JSON 객체 정렬
  var levelResult = gemsJson["GemsData"].sort((a,b) => {return b.GemsLevel - a.GemsLevel})

  // JSON to String
  var gemsName = "";
  var gemsEffect = "";
  gemData = "";
  for (i = 0; i < gemsJson["GemsData"].length; i++){
    gemsName = levelResult[i]["GemsName"];
    gemsEffect = levelResult[i]["GemsEffect"];
    gemData += gemsName + gemsEffect + "\n";
  }
  var _gemData = gemData.slice(0, gemData.length - 1);
  var _gemData2 = _gemData.replace(/\n /gi, "\n");
  var _gemData3 = _gemData2.slice(1);
  return _gemData3;
}

// Data 가공
function checkInputForData(input, _resultAPI){
  resultData = "";
  switch (input) {
    case "!배럭":
      resultData = Characters(_resultAPI);
        break;
    case "!정보":
        break;
    case "!보석":
      resultData = Gems(_resultAPI);
        break;
    case "!아바타":
        break;
    case "!스킬":
      resultData = Skills(_resultAPI);
        break;
  }
  return resultData;
}

// URL 생성
function checkInputForURL(_input){
  switch (_input) {
    case "!배럭":
      arrNumF = 0;
      arrNumB = 0;
      usingKaling = false;
        break;
    case "!정보":
      arrNumF = 0;
      arrNumB = 1;
        break;
    case "!보석":
      arrNumF = 1;
      arrNumB = 7;
      usingKaling = false;
        break;
    case "!아바타":
      arrNumF = 1;
      arrNumB = 3;
        break;
    case "!스킬":
      arrNumF = 1;
      arrNumB = 4;
      kalingTpye = 0;
      usingKaling = true;
        break;
  }
}

// 카카오링크 템플릿
function checkTemplatesKakaolink(_kalingTpye, room, _output){
  switch (_kalingTpye) {
    case 0:
      kalingList(room, _output);
      Log.debug('room='+ room)
        break;
    case 1:
        break;
    case 2:
        break;
    case 3:
        break;
    case 4:
        break;
  }
}

// 카카오링크 리스트 4개짜리
function kalingList(room, data){
  Kakao.sendLink(room, {
    template_id: 95682 , //템플릿 아이디 5자리
    template_args: {
      // THU: '1',
      // title1: '1',
      // like_count: '1',
    }
  }, 'custom').then(e => {
    Log.debug('카링 보내기 성공!')
}).catch(e => {
  Log.debug('ERRR='+e);
});
  // for (var i = 0; i < _titleData.length; i += 12) {
  //   Kakao.sendLink(room, {
  //     // 89825 89041
  //     template_id: 89825, //템플릿 아이디 5자리
  //     template_args: {
  //       // header: _header[0], 
  //       // title1: _titleData[i],
  //       // title2: _titleData[i+3],
  //       // title3: _titleData[i+6],
  //       // title4: _titleData[i+9],

  //       // img1:_titleData[i+1],
  //       // img2:_titleData[i+4],
  //       // img3:_titleData[i+7],
  //       // img4:_titleData[i+10],

  //       // text1:_titleData[i+2],
  //       // text2:_titleData[i+5],
  //       // text3:_titleData[i+8],
  //       // text4:_titleData[i+11],

  //       header: '1',
  //       title1: '1',
  //       title2: '1',
  //       title3: '1',
  //       title4: '1',

  //       img1: '2',
  //       img2: '2',
  //       img3: '2',
  //       img4: '2',

  //       text1: '3',
  //       text2: '3',
  //       text3: '3',
  //       text4: '3',
  //       // text5:"test12314124",
  //     }
  //   }, 'custom').then(e => {
  //     Log.debug('카링 보내기 성공!')
  // }).catch(e => {
  //   Log.debug('ERRR='+e);
  // });
  // }
}

// getAPI
function getAPI (_url){
  try {
    var res = org.jsoup.Jsoup.connect(apiBaseURL + _url)
    .header("accept", "application/json") 
    .header("authorization", apiKey)
    .ignoreHttpErrors(true)
    .ignoreContentType(true)
    .get().text();
    // JSON 문자열을 객체로 반환
    var data = JSON.parse(res);
    return data;
  } catch (e) {
    return e;  
  }
}

// String to Array
function strToArr(str){
  var _str = str.split("\n");
  return _str
}

// 초기화
function init(){
  charaterName = "";
  arrNum = 0;
  arrArmorNum = 0;
  arrMarketNum = 0;
}

//아래 4개의 메소드는 액티비티 화면을 수정할때 사용됩니다.
function onCreate(savedInstanceState, activity) {
  var textView = new android.widget.TextView(activity);
  textView.setText("Hello, World!");
  textView.setTextColor(android.graphics.Color.DKGRAY);
  activity.setContentView(textView);
}

function onStart(activity) {}

function onResume(activity) {}

function onPause(activity) {}

function onStop(activity) {}

function onNotificationPosted(sbn, sm) {
  var packageName = sbn.getPackageName();
  if (!packageName.startsWith("com.kakao.tal")) return;
  var actions = sbn.getNotification().actions;
  if (actions == null) return;
  var userId = sbn.getUser().hashCode();
  for (var n = 0; n < actions.length; n++) {
      var action = actions[n];
      if (action.getRemoteInputs() == null) continue;
      var bundle = sbn.getNotification().extras;

      var msg = bundle.get("android.text").toString();
      var sender = bundle.getString("android.title");
      var room = bundle.getString("android.subText");
      if (room == null) room = bundle.getString("android.summaryText");
      var isGroupChat = room != null;
      if (room == null) room = sender;
      var replier = new com.xfl.msgbot.script.api.legacy.SessionCacheReplier(packageName, action, room, false, "");
      var icon = bundle.getParcelableArray("android.messages")[0].get("sender_person").getIcon().getBitmap();
      var image = bundle.getBundle("android.wearable.EXTENSIONS");
      if (image != null) image = image.getParcelable("background");
      var imageDB = new com.xfl.msgbot.script.api.legacy.ImageDB(icon, image);
      com.xfl.msgbot.application.service.NotificationListener.Companion.setSession(packageName, room, action);
      if (this.hasOwnProperty("responseFix")) {
          responseFix(room, msg, sender, isGroupChat, replier, imageDB, packageName, userId != 0);
      }
  }
}